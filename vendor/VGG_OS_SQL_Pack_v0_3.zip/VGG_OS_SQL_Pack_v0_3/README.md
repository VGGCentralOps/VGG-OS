# VGG OS SQL pack v0.3.0

Fresh-install database baseline, 3 November 2026. Finance is the first domain of the wider group platform.

## Start here

This pack supersedes the v0.2 database design for a **new, empty database**. It is not an in-place migration. It contains no DROP DATABASE / DROP SCHEMA commands, live connections or credentials. Keep a copy of the prototype before rebuilding. The UI/API must be adapted to the new names and contracts; the old queries are not compatible.

Required: PostgreSQL 15 or later, PL/pgSQL (included by default), and psql for the installer. No extensions or UUID plugins are required. The installation has been executed on PostgreSQL 18.6 through PGlite; this does not validate Azure deployment, network access or IAM integration. Re-run the supplied checks on the chosen PostgreSQL service/version before deployment.

From this extracted directory, with IT's approved connection configured:

```bash
psql "$VGG_DATABASE_URL" -X -v ON_ERROR_STOP=1 -f install.sql
psql "$VGG_DATABASE_URL" -X -v ON_ERROR_STOP=1 -f tests/001_regression.sql
psql "$VGG_DATABASE_URL" -X -v ON_ERROR_STOP=1 -f tests/002_catalogue_checks.sql
```

`install.sql` applies twelve scripts in order. Scripts commit individually and intentionally fail if baseline objects already exist; they must not be re-run as an upgrade. If an installation fails, retain the error, fix the cause and have IT prepare a clean disposable database for the next installation. Do not run this over the prototype or a populated environment.

The regression script creates synthetic fixtures inside a transaction and rolls them back. It must be run on an isolated test database, not during live operation. Identity sequence gaps after the test are normal. Real financial report values, dates, bank numbers, API endpoints, account mappings and user permissions are **not** seeded.

## Delivery 1

Proposed target: Friday 6 November 2026, subject to developer confirmation of access, files and extraction scope.

1. Load and present the existing Finance group report outputs, including available historical periods; preserve their agreed layout, values, units, currencies and source versions. Provide report/period selection and exports.
2. Connect one BC subsidiary, load the agreed Finance data into raw/staging and the required normalised tables, reconcile to agreed source checks and prove safe repeat loading.

These are independent outputs. A successful BC load does not mean BC has reproduced the group reports. Imported Finance figures remain labelled `FINANCE_PREPARED`; automated outputs are separately labelled `SYSTEM_CALCULATED`.

There are fourteen worksheet candidates in the supplied workbook, while Delivery 1 was described as thirteen reports. The candidate seed retains all fourteen as PENDING; Finance must confirm whether the two weekly cash sheets are one report, and the final catalogue. There are no approved report layouts or invented financial formulas in the seed.

## Included

| Script | Purpose |
|---|---|
| 001 | Shared entities, periods, currencies, units, datasets and reserved future domain schemas |
| 002 | External identity references, optional entitlement mappings, audit and export events |
| 003 | Source systems/instances/companies, files, API sync streams, runs, raw records and validation |
| 004 | Report catalogues, versioned layouts, series, typed cells, publication, coverage and adjustment evidence |
| 005 | Immutable approved reports/layouts and controlled report publication |
| 006 | Provisional accounts/TB model, source selection, GL projection, pinned calculations and FX inputs |
| 007 | Mono balances, BC book balances, submission events, incubated allocations, intercompany positions, debt and partner expenses |
| 008 | Template/field dictionary, mappings, quality/lineage registers, future AI metadata and input/evidence guards |
| 009 | Published reporting, historical reporting, selected TB, bank and operational serving views |
| 010 | Reference seeds; eight input placeholders, two named and six awaiting definition |
| 011 | Fourteen provisional workbook catalogue candidates |
| 012 | Revoke PUBLIC access and function execution; no runtime account or access grant is created |

See `docs/DEVELOPER_RUNBOOK.md`, `docs/DATA_MODEL.md`, `docs/SECURITY_AND_IAM.md`, `docs/CHANGELOG_AND_DECISIONS.md` and `tests/TEST_REPORT.md`.

## Scope limits

SQL establishes storage, keys, integrity and selected workflow guards. The developer still implements BC/Mono clients, file parsers, jobs, server authorisation, validation and reconciliation execution, the Finance approval UI, calculation engine, exports and monitoring. This pack does not connect to any external API or generate the thirteen reports automatically.

The accounting structures are provisional contracts until the eight standardised templates and Finance rules are confirmed. The six unnamed inputs are metadata placeholders, not generic untyped financial fact tables. Other domains have reserved schemas only; domain models should be introduced through reviewed migrations.
