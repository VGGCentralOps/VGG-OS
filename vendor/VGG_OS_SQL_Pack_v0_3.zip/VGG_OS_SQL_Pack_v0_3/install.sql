\set ON_ERROR_STOP on
\ir sql/001_core.sql
\ir sql/002_identity_audit.sql
\ir sql/003_source_ingestion.sql
\ir sql/004_reporting.sql
\ir sql/005_reporting_controls.sql
\ir sql/006_accounting_inputs.sql
\ir sql/007_banking_operations.sql
\ir sql/008_dictionary_governance.sql
\ir sql/009_serving_views.sql
\ir sql/010_reference_seed.sql
\ir sql/011_report_catalogue_candidates.sql
\ir sql/012_security_baseline.sql
