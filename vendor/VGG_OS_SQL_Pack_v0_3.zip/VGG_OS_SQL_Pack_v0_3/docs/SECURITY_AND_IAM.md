# Security boundary and corporate identity

## What SQL does

- References the existing corporate identity provider by issuer/tenant and stable external subject. Email is display/contact data, not the identity key.
- Stores optional external group/app-role to action/module/entity/dataset mappings. No passwords or parallel directory are created.
- Revokes PUBLIC access to application schemas/tables/sequences/functions. No runtime login or entitlement is seeded.
- Enforces selected integrity and approved-history rules, with invoker-rights functions. No SECURITY DEFINER escalation is used.
- Keeps append-only audit events and exact published version references for export auditing.

## What the backend must do

Validate provider signatures, issuer, audience, token lifetime and trusted group/app-role claims. Resolve identity from the verified token; never accept arbitrary actor_id, report_id, scope or group lists from the browser as proof of access.

Authorise the intersection of action, module, report/dataset, entity and information sensitivity before every query, export, upload and approval. An allowed dataset is not permission for every entity. Group totals are independently sensitive and may disclose subsidiaries the viewer cannot otherwise see. Masked bank account displays do not authorise unrestricted account data.

The entitlement mapping is optional: if corporate app roles already express all permissions, use them. If local mappings are necessary, define/test their semantics explicitly. No SQL function evaluates these mappings. A future RLS design needs a trustworthy identity propagation mechanism and separate testing, rather than unverified client-set session variables.

**This baseline uses a private, trusted backend service security boundary, not per-user RLS.** Published views filter status/version, not viewer entitlements. Never grant end users direct access on the assumption that a view filters their subsidiaries. API service credentials can see more than any individual user, so backend checks are mandatory.

## Provisioning

Have IT create NOLOGIN permission groups and separate private service logins. Do not use the installer/owner as a runtime user. Use encrypted connections and secret-store references. Example group design (not automatically executed):

- Reader: USAGE on the needed schemas and SELECT on approved serving views only. Base table/raw/evidence/IAM/audit access is not necessary for a basic management reader. View access still requires backend scope enforcement.
- Ingestion worker: only the source, reference lookup and domain-fact privileges its adapter needs, relevant sequences and EXECUTE on complete_run. Do not grant ownership or report-publication privileges to an extractor.
- Report loader: DRAFT report/layout operations and source import operations appropriate to its service.
- Publication service: required report status/publication operations and EXECUTE on publish_report after an authorised Finance action. This invoker function requires underlying UPDATE/INSERT/SELECT/sequence privileges; granting EXECUTE alone is insufficient.
- Audit writer: INSERT only on required audit tables/sequences; readers/retention administrators separately authorised.

Use a dedicated human-controlled migration role for schema changes. Privilege scripts are environment-specific because the actual directory, roles, ownership and deployment model remain to be agreed. This pack intentionally does not grant broad runtime access under guessed role names.

Triggers are not protection against the owner or a superuser. Append-only rows also need operational access control and backups. Audit external failures/denials in a separate transaction where the business transaction was rolled back; PostgreSQL has no autonomous audit transaction here.

No bank-account tokens, raw sensitive payloads, full account numbers or financial detail should enter application logs. Confirm evidence URI access and redaction. Bank/partner detail should have narrower scopes than general Finance summaries.
