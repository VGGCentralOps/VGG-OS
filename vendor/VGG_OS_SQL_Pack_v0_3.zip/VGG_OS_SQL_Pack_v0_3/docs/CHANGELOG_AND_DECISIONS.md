# Changes from v0.2 and decisions to confirm

## Rebuilt model

- Shared schemas retained conceptually; future domain schemas reserved without speculative placeholder fact tables.
- Local role/user administration replaced with external identity references and optional entitlement mappings.
- Generic report amounts replaced with versioned row/column layouts and typed cells; publication period and observed period can differ. Supports currency, scale, percentages, days, commentary and missing values.
- One mutable submission per report-period replaced with series, immutable approved versions and a current publication pointer.
- Prepared historical report outputs distinguished from calculated reports. Raw imports and source evidence remain traceable.
- API instances/companies, independent endpoint sync streams, raw records, validation and atomic checkpoint completion added.
- Provisional CoA/TB/account mapping and explicit primary-source selection added. Source versions pinned for automated report runs.
- Bank snapshots separated from BC book balances; refresh errors retain previous observations without substituting zero.
- Submission event/deadline model, supporting intercompany/debt/partner/incubated data and business dictionary registers added.
- Published management and historical approved views replace the unfiltered report view. No end-user access is inferred merely from approved status.
- Future AI routes blocked by default; no model or agent deployment included.

## Naming and compatibility

This is a new baseline, not backward-compatible DDL. Examples: core.legal_entity becomes core.entity; finance.report_submission becomes report_series/report_version; finance.report_value becomes report_cell; source.ingestion_batch becomes ingestion_run. The UI/API must be adapted, not pointed at this schema unchanged. Do not run the v0.2 seed/demo/validation files after this installer.

## Outstanding decisions

| Decision | Owner | Impact |
|---|---|---|
| Thirteen reports versus fourteen worksheet candidates; weekly cash parts | Banke / Finance | Final catalogue and acceptance scope |
| Populated historical outputs and expected periods | Finance | Delivery 1 report data and reconciliation |
| Eight input template structures; six unnamed | Project team / Finance | Typed input tables and final validations |
| Entity aliases, legal/reporting structure, functional currencies | Finance | Mapping, aggregation, permissions and FX |
| BC instances, company IDs, endpoints, authentication, network access | ERP / Engineering | First extraction and scheduling |
| Corporate identity provider, verified entitlements and runtime roles | Engineering / IT | Authentication and all user data access |
| Account mappings, TB readiness, signs and source precedence | Finance | Accurate automated reporting |
| Revenue/cash sources and liability mapping for compliance | Finance | Compliance automation |
| Heat-map deadline/day counting/accepted event/score | Finance | Submission status automation |
| Mono corporate account coverage, consent and freshness | Finance / Engineering | Cash visibility |
| Consolidation, FX, intercompany and variance rules | Finance | Group calculations and comparability |
| Actual SQL service/version, environments and support ownership | IT / developer | Deployment and operation |

The rebuild is intentionally not delayed by unknown future-domain definitions. Add reviewed typed models/mappings/UI through migrations as their requirements become concrete. New reports using existing facts may need configuration; new financial facts usually require new schema and transformation code.
