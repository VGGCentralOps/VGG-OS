# Data model and conventions

## Shared foundation

`core.entity` represents the group, legal entities and incubated beneficiaries. It does not assume every reporting label is a separate incorporated subsidiary. Confirm aliases such as GV, VGN and Manco. Only VGG_GROUP is seeded; do not infer subsidiary currency/country from its name. `core.organisation_unit` belongs to one entity and uses composite foreign keys where linked to facts.

`core.period` holds real start/end dates and kind, including YTD and custom periods. Workbook dates such as January 26 may be formatting/encoding artefacts; validate against the report title and Finance before converting them to reporting periods. Preserve original source text. Period metadata and entity identifiers must remain stable once referenced by approved history; corrections need reviewed migrations and documented impact.

`core.dataset` is the common catalogue. `core.template_contract` holds the eight pending input contracts. Field definitions separate business approval from technical verification. Physical columns can be inspected through `core.v_physical_dictionary`; this does not replace Finance-approved business definitions.

## Sources and ingestion

System → instance → company → sync stream → run → raw records. A stream is scoped by company, endpoint and a canonical query-scope hash. Persist authentication *references* and network notes, never secrets. The company key is unique within its instance, not across BC installations.

File → file records (sheet/cell/row reference) → report cells or input facts. File metadata stores a SHA-256 content hash and protected storage reference. Copies of the same file may have different upload records; adapter logic uses content identity/idempotency keys to prevent duplicate processing. The content store must enforce retention/access; PostgreSQL cannot prevent the underlying file being replaced elsewhere.

Every run is either API stream-backed or file-backed. Raw records are append-only per run/source key/source version, preserving multiple extraction versions across runs. Use actual provider version metadata where available; otherwise use an explicitly documented payload-hash version policy. `gl_entry` is the current projection, upserted by company/source entry key; raw extraction history remains intact. Missing records are not assumed deleted without the endpoint's deletion semantics/full-snapshot reconciliation.

## Report output model

Report → versioned layout (rows and columns).
Report + publication period + reporting scope + variant → series → output versions → typed cells.
Publication points to one APPROVED version for each series. A replacement creates a new version and supersedes the previous version atomically; historical versions remain queryable.

Rows describe headings/lines/subtotals and optional entity labels. Columns describe observed period, scenario, entity, unit, currency, scale and type. Cells can override unit/currency/entity for mixed layouts. Row/column `dimension_labels` are display metadata, not a substitute for typed accounting facts or source mappings. For intercompany detail use explicit book/counterparty entities in the supporting model.

Cell grain is **version + row + column**. The layout must define separate row/column slots for every distinct observation. Do not collapse the thirteen reports into one undifferentiated amount table. Do not create a physical table per report either. Repeated entity/period blocks can render through reusable UI components over these definitions.

Cells hold exactly one number, text, date or boolean when PRESENT. MISSING, NOT_APPLICABLE and SUPPRESSED have no stored value; zero is a real numeric value. Headings need not have cells. A missing cell must not be implicitly rendered as zero.

Canonical money amounts are in major currency units. Display value = canonical number / column display_scale. Example: NGN 1,250,000 displayed in N'000 has scale 1,000 and displays 1,250. Import a workbook's displayed number by multiplying by its confirmed scale. Percent values are percentage points (12.5 means 12.5%), with scale 1. Ratios/days/counts have their own units. Do not reuse currency formatting for them. Currency is mandatory on present monetary numbers; never aggregate different currencies without agreed FX treatment.

`report_coverage` records expected/received/loaded/accepted/unavailable report-period scope; it is separate from publication. A loaded blank template is not an accepted financial report.

`cell_adjustment` records explanations and whether an adjustment is already included in the final stored cell. Serving views never add adjustment amounts. Changing final figures or evidence after publication requires a replacement output version.

## Standard accounting model (provisional)

Entity local accounts → approved, effective-dated mapping set → group accounts.
TB header: entity + period + currency + basis + source route + version.
TB line: header + account + optional organisation unit + canonical dimension key.

Canonical signed amount = debit minus credit. Confirm incoming signs, opening/movement/YTD/closing basis, currencies and row grain against the actual template. The supplied templates may require additional attributes and new fact tables.

A single reporting_source_selection designates the approved primary TB for each entity/period/currency/basis. BC and subsidiary uploads are not automatically additive. Source changes create history. Supplements and replacements require explicit non-overlap rules; this pack does not merge two TBs by assumption.

A calculation run pins mapping/rule versions, exact TB versions and exact FX rows. Source selection can change later without changing that run's inputs. The calculation engine must record the full required inputs and cell lineage before marking a run successful. No consolidation, elimination, variance, interest or tax engine is implemented by these tables. Approved mappings cannot contain overlapping effective dates for the same local account.

## Cash and operational supporting facts

Bank account → provider connection → append-only balance snapshots. Bank account → BC account mapping → separately stored book balance. Bank amounts retain raw units/divisor as well as canonical amount; unit conversion must reconcile exactly. Do not derive freshness solely from request time. Preserve unknown source time, failed refresh status, missing account coverage and expired consent.

`v_latest_bank_balance` returns the last successfully retrieved observation per account and balance type. Retrieval order is not a guarantee of provider freshness; use source/refresh timestamps and show their uncertainty. It intentionally excludes any total across currencies and does not claim cash-book reconciliation.

Submission requirements and submission events are independent of amounts. Capture actual submission evidence, not ingestion completion time. The workbook says positive=early, negative=late, zero=on time; Finance still confirms deadlines, day counting, which correction counts, colours and scoring.

Incubated expense allocations preserve beneficiary, payer, category, amount/currency, payment reference and evidence. No expense request, approval-routing or payment-execution application is silently introduced.

Intercompany positions retain both book entity and counterparty. Debt schedules distinguish actual, scheduled and forecast figures. Partner expenses are restricted detail and retain separate currency observations. These structures are available for later source-based reporting; Delivery 1 may simply load prepared report outputs.
