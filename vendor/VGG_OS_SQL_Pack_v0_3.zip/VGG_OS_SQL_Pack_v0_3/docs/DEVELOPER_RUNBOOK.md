# Developer runbook

## Installation and implementation order

1. Preserve the prototype/repository. Confirm PostgreSQL product/version, hosting, private network route and repository setup. Install this baseline in a new disposable development database using `install.sql`.
2. Run both supplied test scripts. Configure the real corporate provider/principal mapping in a separate environment-specific migration. No active entitlement or source instance is seeded.
3. Confirm Finance's report inventory: fourteen worksheet candidates versus thirteen agreed reports; record each report's owner, cadence, units, currency, source file, available history and whether monthly values are movements or cumulative.
4. Build report layouts from the supplied workbook. Rows/columns must be reviewed; no template values or formulas are inferred. Approved layouts are immutable. Period-specific monthly/year comparison labels may require a new layout version per reporting issue; reusing identical compatible layouts is optional. This is deliberate for faithful first delivery, not a final automated layout generator.
5. Load historical prepared outputs. Build the management report/period selection and export against the published version. Render and reconcile against the same source file. Record missing history through coverage metadata.
6. Connect one BC company and load the agreed endpoints/date range. Test safe retries and control totals. BC ingestion proceeds separately from loading the prepared reports.
7. When templates arrive, implement standard accounting contracts, source precedence and one full automated report path; expand after Finance accepts it. Mono cash visibility can follow when consent/API access is ready.

## Prepared report import transaction

- Authenticate the caller; resolve the principal from externally verified identity. Authorise upload for this report and scope.
- Store the source file in protected evidence storage. Compute SHA-256; register `source.file`, sheet/row/cell evidence and a file ingestion run with a stable idempotency key.
- Create/reuse an agreed report catalogue entry and layout; add rows/columns while the layout is DRAFT. Validate the layout, then set it APPROVED with the authorised actor and date.
- Resolve periods, entity aliases, currencies and scales; reject ambiguous dates. Do not silently convert text currency values, dashes or blanks to zero.
- Create the series if absent. Allocate the next version number while holding a series lock (`SELECT ... FOR UPDATE`); never use unprotected MAX(version_no)+1 under concurrency. Create the DRAFT version with origin FINANCE_PREPARED and file/run references.
- Insert cells, validation evidence, source references, lineage and any adjustment explanations. Reconcile loaded values against supplied report totals and detail. Record missing scope.
- Mark the import run VALIDATED, set record counts, then invoke `source.complete_run`. Mark report SUBMITTED only after the accepted import is complete.
- An authorised Finance reviewer accepts the report. The trusted backend calls `finance.publish_report(version_id, actor_id, note)`. It verifies lifecycle, records approval, replaces the current publication and appends an audit event transactionally. It does **not** decide whether this actor has approval authority: server authorisation does that before the function call.
- Management reads `finance.v_published_cells` with server-enforced report/entity/dataset restrictions. Finance review reads draft tables through separate authorised endpoints. Rejected/unpublished/superseded versions are never selected by the management current view.
- An export resolves the permitted series/version once, uses that version for all rows, records filters and export audit, and streams only permitted fields. Log failures/denials separately. Historic approved export must be explicitly authorised; never silently substitute the current version.

## BC connector

Use the supplied BC230 API guide; this pack deliberately contains no endpoints, credentials, company IDs or bank details. Confirm both on-premises instances, independent authentication methods, HTTPS route, VPN/gateway/domain requirements, and the actual company/endpoint payload schemas. Corporate sign-in and BC service authentication are separate integrations.

Create instance/company mappings and a sync stream per endpoint/query scope. Store credentials in the approved secret store. Use read-only BC access.

1. Lock/check a stream and create a RUNNING run with checkpoint_before copied from the committed checkpoint. Only one RUNNING run per stream is permitted.
2. Fetch all pages with bounded retries/timeouts. Append raw records with provider keys/version metadata; on a retried page use ON CONFLICT DO NOTHING only for the exact raw record uniqueness key, not broad exception suppression. Retain extraction timestamps and deletion flags where supported.
3. Validate required fields, row counts, amounts, company mappings and source control totals. Write result rows. Unmapped/rejected records remain visible. Domain facts must be upserted using company-scoped source keys. Date-scope/hash changes need a distinct stream or controlled backfill policy.
4. In one transaction, upsert the normalised facts needed for this load, set run counts/checkpoint_after and status VALIDATED, then invoke `source.complete_run`. If validation/completion fails, roll back those normalised changes. The function advances the checkpoint only if the previous committed checkpoint still matches and no recorded blocking validation failed.
5. On failure, retain raw evidence, set the run FAILED, and leave the committed checkpoint unchanged. Restart with a new attempt/run and idempotency key. Source projection uniqueness prevents duplicates. Record failure state in a fresh transaction after the work transaction rolls back.
6. Schedule refresh/backfills after initial reconciliation. A BC extraction date is not proof Finance has completed month-end adjustments; obtain readiness confirmation before using a TB for publication.

The SQL cannot prove that all API pages were read or every required validation was recorded. The connector and acceptance checks must establish completeness. It also cannot detect source deletions absent provider semantics or an agreed full-snapshot comparison.

## Mono connector

Confirm supported accounts/banks, consent owner, amount units, returned balance type, data availability, refresh timestamps and agreed freshness threshold from actual integration responses. Do not assume the API is real-time.

Register masked bank accounts, private provider account identifiers and connection status. Use raw provider units/divisor to create canonical balance snapshots. A provider snapshot key must be stable for a retried observation. When the provider has no immutable snapshot ID, derive an observation key from the persisted retrieval attempt and payload identity; reuse it on retries. Do not deduplicate forever by amount alone, since unchanged balances can be valid later observations.

Create no snapshot on failed/unavailable data. Update connection attempt/error/reauthorisation state and show the last successful observation with its actual timing. Store BC book balances separately. Balance-only differences are not automatic transaction reconciliation. Cross-currency totals require approved FX and conversion dates.

## Finance validation before automation

- Eight actual templates, including CoA/TB; define row grain, signs, units, period basis, required fields and approval.
- Local/group account mappings and effective dates. Do not match production accounts by similar text alone.
- VAT and WHT mappings for payable-minus-receivable as described in the lineage; confirm signs and treatment with Finance. Other liability mappings, revenue and liquidity sources remain outstanding.
- Monthly/YTD logic; MoM/YoY/budget denominators, zero-denominator and missing-comparator behaviour; liability timing, consolidation, intercompany, FX and adjustment rules.
- Heat-map event/deadline/counting/score definitions; incubated allocation and evidence completeness. Do not assume emails or bank narrations encode beneficiary company correctly.

## Operating controls

Use migrations after this baseline; do not edit an applied script and re-run the installer. Track migration checksums and release versions in source control. Schema version table records this baseline only, not a migration engine.

Define private backend identities, restricted uploads, evidence retention, secrets rotation, error redaction, job monitoring/alerts, backup/restore and deployment rollback ownership. Test restore in a separate environment. Restrict production writes to the minimum services and roles; no browser/client has database credentials. Routine report corrections use new versions, not owner bypass of triggers.

Before user release: test actual corporate identity claims, scope checks on screen/drill-down/export, Finance accuracy, actual BC repeat refresh, alert behaviour and account coverage. These integration tests cannot be replaced by schema regression tests.
