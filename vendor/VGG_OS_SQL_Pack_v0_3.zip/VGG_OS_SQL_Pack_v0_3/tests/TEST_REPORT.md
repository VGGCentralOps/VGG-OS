# Verification report

3 November 2026.

All twelve installation scripts executed successfully against a clean PostgreSQL 18.6 engine through PGlite 0.5.15. 41 regression assertions passed. Test data rolls back.

The checks cover typed/missing report values, display scaling, cross-report relationships, immutable publication history, correction versions, approved layouts, cross-entity TB references, duplicate TB grain, month-end readiness, approved source selection, API raw-record uniqueness, GL upserts, validation-gated checkpoints, retained bank balances after refresh failure, unit conversion, snapshot retry uniqueness, calculation pinning, effective-date mapping overlaps, append-only evidence/audit and PUBLIC schema access.

This does not establish production readiness or verify corporate IAM, actual BC/Mono APIs, HTTPS/networking, multi-session concurrency/deadlocks, hosting, operational backups or Finance calculation accuracy. PostgreSQL 15+ compatibility is the design target; actual execution was on version 18.6. Run the psql tests and integration checks on the chosen service/version.

## Results

- PASS: Approved TB lines immutable
- PASS: Approved account mappings immutable
- PASS: Approved history retains original figure
- PASS: Approved layout member immutable
- PASS: Audit events append-only
- PASS: Bank retry snapshot unique
- PASS: Bank units must reconcile
- PASS: Calculated report publishes after pinned run
- PASS: Calculated report requires successful pinned run
- PASS: Cross-entity TB account rejected
- PASS: Cross-report layout rejected
- PASS: Display scaling exact
- PASS: Drafts excluded from published view
- PASS: Duplicate TB grain rejected
- PASS: Eight template placeholders only
- PASS: Exactly one current published version
- PASS: Failed run leaves checkpoint unchanged
- PASS: Failed validation blocks checkpoint commit
- PASS: Fourteen workbook candidates remain provisional
- PASS: GL projection rerun is idempotent
- PASS: Missing cells remain null
- PASS: Money requires explicit currency
- PASS: Month-end readiness required
- PASS: No PUBLIC application schema usage
- PASS: No direct approved insert
- PASS: No seeded external AI route
- PASS: Overlapping effective mappings cannot be approved
- PASS: Published cell immutable
- PASS: Published series identity immutable
- PASS: Raw evidence cannot be overwritten
- PASS: Raw record retry is unique
- PASS: Refresh failure retains prior balance and error
- PASS: Selected source contains one TB
- PASS: Source evidence immutable
- PASS: Successful calculation inputs immutable
- PASS: Successful ingestion history immutable
- PASS: Superseded version retained
- PASS: Typed cells reject number in text column
- PASS: Unapproved TB selection rejected
- PASS: Unapproved publication rejected
- PASS: Validated run commits checkpoint
