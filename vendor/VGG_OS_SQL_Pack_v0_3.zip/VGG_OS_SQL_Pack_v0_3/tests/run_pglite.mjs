// Optional reproducible local verification. Requires Node and @electric-sql/pglite.
// This is a transient embedded PostgreSQL check; use psql tests on the actual deployment too.
import { PGlite } from '@electric-sql/pglite';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const db=new PGlite();
try {
  const engine=(await db.query('select version()')).rows[0];
  for (const name of fs.readdirSync(path.join(root,'sql')).filter(n=>n.endsWith('.sql')).sort()) {
    await db.exec(fs.readFileSync(path.join(root,'sql',name),'utf8'));
    console.log('PASS install',name);
  }
  const results=await db.exec(fs.readFileSync(path.join(root,'tests','001_regression.sql'),'utf8'));
  const tests=results.flatMap(r=>r.rows??[]).filter(r=>r.name&&r.passed!==undefined);
  console.log(JSON.stringify({engine,passed:tests.length,tests},null,2));
} catch(e) {
  console.error('FAILED',e.message,e.detail??'',e.where??'');
  process.exitCode=1;
} finally {
  await db.close();
}
