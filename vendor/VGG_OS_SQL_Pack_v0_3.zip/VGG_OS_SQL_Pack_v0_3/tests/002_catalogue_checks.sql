\set ON_ERROR_STOP on
SELECT version();
SELECT * FROM core.schema_version;
SELECT table_schema,count(*) AS base_tables FROM information_schema.tables
 WHERE table_type='BASE TABLE' AND table_schema IN ('core','iam','source','finance','audit','ai') GROUP BY table_schema ORDER BY table_schema;
SELECT code,name,catalogue_status,source_sheet FROM finance.report ORDER BY id;
SELECT d.code,c.version_no,c.status FROM core.template_contract c JOIN core.dataset d ON d.id=c.dataset_id ORDER BY d.code;
SELECT n.nspname,p.proname,p.prosecdef AS security_definer FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
 WHERE n.nspname IN ('source','finance','audit') ORDER BY n.nspname,p.proname;
-- All triggers must be enabled and foreign keys/checks validated.
SELECT t.tgname,t.tgenabled FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace
 WHERE NOT t.tgisinternal AND n.nspname IN ('finance','source','audit') ORDER BY t.tgname;
SELECT conname FROM pg_constraint c JOIN pg_namespace n ON n.oid=c.connamespace
 WHERE n.nspname IN ('core','iam','source','finance','audit','ai') AND NOT c.convalidated;
