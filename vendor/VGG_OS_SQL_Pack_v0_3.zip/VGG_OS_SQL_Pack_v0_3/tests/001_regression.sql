-- Run only against an isolated database after install.sql. All test data rolls back.
BEGIN;
CREATE TEMP TABLE test_result(name text PRIMARY KEY, passed boolean NOT NULL);
CREATE FUNCTION pg_temp.assert_ok(test_name text, condition boolean) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
 IF condition IS DISTINCT FROM true THEN RAISE EXCEPTION 'FAILED: %',test_name; END IF;
 INSERT INTO test_result VALUES(test_name,true);
END $$;
CREATE FUNCTION pg_temp.expect_error(test_name text, command text, expected_state text) RETURNS void LANGUAGE plpgsql AS $$
DECLARE caught boolean:=false; actual_state text; BEGIN
 BEGIN EXECUTE command;
 EXCEPTION WHEN OTHERS THEN
  GET STACKED DIAGNOSTICS actual_state=RETURNED_SQLSTATE;
  IF actual_state<>expected_state THEN RAISE EXCEPTION 'FAILED: %, expected %, got %',test_name,expected_state,actual_state; END IF;
  caught:=true;
 END;
 PERFORM pg_temp.assert_ok(test_name,caught);
END $$;
DO $$
#variable_conflict use_variable
DECLARE provider bigint; actor bigint; entity bigint; other_entity bigint; period bigint; dataset bigint;
 fileid bigint; report bigint; other_report bigint; layout bigint; other_layout bigint; rw bigint; col bigint; txtcol bigint;
 series bigint; v1 bigint; v2 bigint; runid bigint; acct bigint; other_acct bigint; tb bigint; tb2 bigint;
 sys bigint; instance bigint; company bigint; stream bigint; api_run bigint; rawid bigint; bank bigint; conn bigint;
 mapset bigint; groupacct bigint; badcol bigint; rules bigint; calcver bigint; calcrun bigint;
BEGIN
 SELECT id INTO dataset FROM core.dataset WHERE code='FINANCE_GROUP_REPORTS';
 INSERT INTO iam.identity_provider(code,issuer,configuration_status) VALUES('TEST','https://test.invalid','CONFIRMED') RETURNING id INTO provider;
 INSERT INTO iam.principal(provider_id,external_subject,principal_type) VALUES(provider,'test-user','USER') RETURNING id INTO actor;
 INSERT INTO core.entity(code,name,entity_type) VALUES('TEST_A','Test A','LEGAL_ENTITY') RETURNING id INTO entity;
 INSERT INTO core.entity(code,name,entity_type) VALUES('TEST_B','Test B','LEGAL_ENTITY') RETURNING id INTO other_entity;
 INSERT INTO core.period(code,name,kind,start_date,end_date,fiscal_year) VALUES('TEST_MONTH','Test month','MONTH','2026-01-01','2026-01-31',2026) RETURNING id INTO period;
 INSERT INTO source.file(file_name,storage_reference,sha256) VALUES('test.xlsx','private://test',repeat('a',64)) RETURNING id INTO fileid;
 INSERT INTO finance.report(code,name,dataset_id) VALUES('TEST_REPORT','Test report',dataset) RETURNING id INTO report;
 INSERT INTO finance.report(code,name,dataset_id) VALUES('TEST_REPORT_OTHER','Other report',dataset) RETURNING id INTO other_report;
 INSERT INTO finance.layout(report_id,version_no) VALUES(report,1) RETURNING id INTO layout;
 INSERT INTO finance.layout(report_id,version_no) VALUES(other_report,1) RETURNING id INTO other_layout;
 INSERT INTO finance.layout_row(layout_id,code,label,display_order,row_type) VALUES(layout,'REVENUE','Revenue',1,'VALUE') RETURNING id INTO rw;
 INSERT INTO finance.layout_column(layout_id,code,label,display_order,value_type,unit_code,currency_code,display_scale)
 VALUES(layout,'ACTUAL','Actual',1,'NUMBER','MONEY','NGN',1000) RETURNING id INTO col;
 INSERT INTO finance.layout_column(layout_id,code,label,display_order,value_type,unit_code)
 VALUES(layout,'NOTE','Note',2,'TEXT','TEXT') RETURNING id INTO txtcol;
 INSERT INTO finance.report_series(report_id,period_id,scope_entity_id) VALUES(report,period,entity) RETURNING id INTO series;
 INSERT INTO finance.report_version(series_id,report_id,layout_id,version_no,origin,source_file_id,created_by)
 VALUES(series,report,layout,1,'FINANCE_PREPARED',fileid,actor) RETURNING id INTO v1;
 INSERT INTO finance.report_cell(version_id,layout_id,row_id,column_id,value_status,numeric_value) VALUES(v1,layout,rw,col,'PRESENT',123000);
 INSERT INTO finance.report_cell(version_id,layout_id,row_id,column_id,value_status) VALUES(v1,layout,rw,txtcol,'MISSING');
 PERFORM pg_temp.assert_ok('Drafts excluded from published view',(SELECT count(*)=0 FROM finance.v_published_cells WHERE report_id=report));
 PERFORM pg_temp.expect_error('Typed cells reject number in text column',format('UPDATE finance.report_cell SET value_status=''PRESENT'',numeric_value=1 WHERE version_id=%s AND column_id=%s',v1,txtcol),'P0001');
 PERFORM pg_temp.expect_error('Cross-report layout rejected',format('INSERT INTO finance.report_version(series_id,report_id,layout_id,version_no,origin,source_file_id,created_by) VALUES(%s,%s,%s,99,''FINANCE_PREPARED'',%s,%s)',series,report,other_layout,fileid,actor),'23503');
 PERFORM pg_temp.expect_error('No direct approved insert',format('INSERT INTO finance.report_version(series_id,report_id,layout_id,version_no,origin,status,source_file_id,created_by,approved_by,approved_at) VALUES(%s,%s,%s,99,''FINANCE_PREPARED'',''APPROVED'',%s,%s,%s,now())',series,report,layout,fileid,actor,actor),'P0001');
 INSERT INTO finance.layout_column(layout_id,code,label,display_order,value_type,unit_code) VALUES(layout,'NO_CURRENCY','Invalid monetary column',3,'NUMBER','MONEY') RETURNING id INTO badcol;
 PERFORM pg_temp.expect_error('Money requires explicit currency',format('INSERT INTO finance.report_cell(version_id,layout_id,row_id,column_id,value_status,numeric_value) VALUES(%s,%s,%s,%s,''PRESENT'',1)',v1,layout,rw,badcol),'P0001');
 UPDATE finance.layout SET status='APPROVED',approved_by=actor,approved_at=now() WHERE id=layout;
 UPDATE finance.report_version SET status='SUBMITTED' WHERE id=v1;
 PERFORM finance.publish_report(v1,actor,'Finance reference checked');
 PERFORM pg_temp.assert_ok('Display scaling exact',(SELECT display_numeric_value=123 FROM finance.v_published_cells WHERE version_id=v1 AND column_id=col));
 PERFORM pg_temp.assert_ok('Missing cells remain null',(SELECT numeric_value IS NULL AND value_status='MISSING' FROM finance.v_published_cells WHERE version_id=v1 AND column_id=txtcol));
 PERFORM pg_temp.expect_error('Published cell immutable',format('UPDATE finance.report_cell SET numeric_value=1 WHERE version_id=%s AND column_id=%s',v1,col),'P0001');
 PERFORM pg_temp.expect_error('Approved layout member immutable',format('UPDATE finance.layout_row SET label=''Changed'' WHERE id=%s',rw),'P0001');
 PERFORM pg_temp.expect_error('Published series identity immutable',format('UPDATE finance.report_series SET variant_code=''MOVED'' WHERE id=%s',series),'P0001');
 INSERT INTO finance.report_version(series_id,report_id,layout_id,version_no,origin,source_file_id,created_by)
 VALUES(series,report,layout,2,'FINANCE_PREPARED',fileid,actor) RETURNING id INTO v2;
 INSERT INTO finance.report_cell(version_id,layout_id,row_id,column_id,value_status,numeric_value) VALUES(v2,layout,rw,col,'PRESENT',124000);
 UPDATE finance.report_version SET status='SUBMITTED' WHERE id=v2;
 PERFORM finance.publish_report(v2,actor,'Corrected Finance output');
 PERFORM pg_temp.assert_ok('Exactly one current published version',(SELECT count(DISTINCT version_id)=1 AND min(version_id)=v2 FROM finance.v_published_cells WHERE report_id=report));
 PERFORM pg_temp.assert_ok('Superseded version retained',(SELECT status='SUPERSEDED' FROM finance.report_version WHERE id=v1));
 PERFORM pg_temp.assert_ok('Approved history retains original figure',(SELECT numeric_value=123000 FROM finance.v_approved_history_cells WHERE version_id=v1 AND column_id=col));
 PERFORM pg_temp.expect_error('Unapproved publication rejected',format('UPDATE finance.publication SET version_id=%s WHERE series_id=%s',v1,series),'P0001');
 PERFORM pg_temp.expect_error('Source evidence immutable',format('UPDATE source.file SET sha256=repeat(''b'',64) WHERE id=%s',fileid),'P0001');
 INSERT INTO source.ingestion_run(file_id,idempotency_key,status,rows_read,rows_accepted) VALUES(fileid,'test-file','VALIDATED',2,2) RETURNING id INTO runid;
 PERFORM source.complete_run(runid,actor);
 PERFORM pg_temp.expect_error('Successful ingestion history immutable',format('UPDATE source.ingestion_run SET status=''FAILED'' WHERE id=%s',runid),'P0001');
 INSERT INTO finance.account(entity_id,account_code,account_name) VALUES(entity,'1000','Cash') RETURNING id INTO acct;
 INSERT INTO finance.account(entity_id,account_code,account_name) VALUES(other_entity,'1000','Other cash') RETURNING id INTO other_acct;
 INSERT INTO finance.trial_balance(entity_id,period_id,currency_code,version_no,basis,source_kind,run_id)
 VALUES(entity,period,'NGN',1,'CLOSING','SUBSIDIARY_UPLOAD',runid) RETURNING id INTO tb;
 PERFORM pg_temp.expect_error('Cross-entity TB account rejected',format('INSERT INTO finance.trial_balance_line(trial_balance_id,entity_id,account_id,debit,credit) VALUES(%s,%s,%s,1,0)',tb,entity,other_acct),'23503');
 INSERT INTO finance.trial_balance_line(trial_balance_id,entity_id,account_id,debit,credit) VALUES(tb,entity,acct,100,0);
 PERFORM pg_temp.expect_error('Duplicate TB grain rejected',format('INSERT INTO finance.trial_balance_line(trial_balance_id,entity_id,account_id,debit,credit) VALUES(%s,%s,%s,100,0)',tb,entity,acct),'23505');
 PERFORM pg_temp.expect_error('Unapproved TB selection rejected',format('INSERT INTO finance.reporting_source_selection(entity_id,period_id,currency_code,basis,trial_balance_id,selected_by,reason) VALUES(%s,%s,''NGN'',''CLOSING'',%s,%s,''Test'')',entity,period,tb,actor),'P0001');
 PERFORM pg_temp.expect_error('Month-end readiness required',format('UPDATE finance.trial_balance SET status=''APPROVED'',approved_by=%s,approved_at=now() WHERE id=%s',actor,tb),'23514');
 UPDATE finance.trial_balance SET status='APPROVED',month_end_ready=true,approved_by=actor,approved_at=now() WHERE id=tb;
 INSERT INTO finance.reporting_source_selection(entity_id,period_id,currency_code,basis,trial_balance_id,selected_by,reason)
 VALUES(entity,period,'NGN','CLOSING',tb,actor,'Agreed primary source');
 PERFORM pg_temp.assert_ok('Selected source contains one TB',(SELECT sum(signed_amount)=100 FROM finance.v_selected_tb WHERE entity_id=entity));
 PERFORM pg_temp.expect_error('Approved TB lines immutable',format('UPDATE finance.trial_balance_line SET debit=999 WHERE trial_balance_id=%s',tb),'P0001');
 SELECT id INTO sys FROM source.system WHERE code='BUSINESS_CENTRAL';
 INSERT INTO source.instance(system_id,code) VALUES(sys,'TEST_BC') RETURNING id INTO instance;
 INSERT INTO source.company(instance_id,external_company_key,entity_id) VALUES(instance,'company-A',entity) RETURNING id INTO company;
 INSERT INTO source.sync_stream(company_id,endpoint_code,scope_hash) VALUES(company,'glEntries','scope-one') RETURNING id INTO stream;
 INSERT INTO source.ingestion_run(stream_id,idempotency_key,status,checkpoint_before,checkpoint_after,rows_read,rows_accepted)
 VALUES(stream,'test-api','VALIDATED','{}','{"watermark":"2026-01-31"}',1,1) RETURNING id INTO api_run;
 INSERT INTO source.raw_record(run_id,record_key,source_version,payload,payload_sha256) VALUES(api_run,'entry-1','v1','{"amount":100}',repeat('c',64)) RETURNING id INTO rawid;
 PERFORM pg_temp.expect_error('Raw record retry is unique',format('INSERT INTO source.raw_record(run_id,record_key,source_version,payload,payload_sha256) VALUES(%s,''entry-1'',''v1'',''{}'',repeat(''c'',64))',api_run),'23505');
 INSERT INTO source.validation_result(run_id,rule_code,severity,passed,message) VALUES(api_run,'CONTROL_TOTAL','BLOCKER',false,'Mismatch');
 PERFORM pg_temp.expect_error('Failed validation blocks checkpoint commit',format('SELECT source.complete_run(%s,%s)',api_run,actor),'P0001');
 PERFORM pg_temp.assert_ok('Failed run leaves checkpoint unchanged',(SELECT committed_checkpoint='{}'::jsonb FROM source.sync_stream WHERE id=stream));
 UPDATE source.validation_result SET passed=true WHERE run_id=api_run;
 PERFORM source.complete_run(api_run,actor);
 PERFORM pg_temp.assert_ok('Validated run commits checkpoint',(SELECT committed_checkpoint->>'watermark'='2026-01-31' FROM source.sync_stream WHERE id=stream));
 INSERT INTO finance.gl_entry(company_id,entity_id,source_entry_key,source_version,account_id,posting_date,currency_code,amount,raw_record_id)
 VALUES(company,entity,'entry-1','v1',acct,'2026-01-31','NGN',100,rawid);
 INSERT INTO finance.gl_entry(company_id,entity_id,source_entry_key,source_version,account_id,posting_date,currency_code,amount,raw_record_id)
 VALUES(company,entity,'entry-1','v1',acct,'2026-01-31','NGN',100,rawid)
 ON CONFLICT(company_id,source_entry_key) DO UPDATE SET amount=excluded.amount;
 PERFORM pg_temp.assert_ok('GL projection rerun is idempotent',(SELECT count(*)=1 FROM finance.gl_entry WHERE company_id=company));
 PERFORM pg_temp.expect_error('Raw evidence cannot be overwritten',format('UPDATE source.raw_record SET payload=''{}'' WHERE id=%s',rawid),'P0001');
 INSERT INTO finance.bank_account(entity_id,code,bank_name,account_display,currency_code) VALUES(entity,'TEST_BANK','Test bank','******1234','NGN') RETURNING id INTO bank;
 SELECT id INTO sys FROM source.system WHERE code='MONO';
 INSERT INTO source.instance(system_id,code) VALUES(sys,'TEST_MONO') RETURNING id INTO instance;
 INSERT INTO finance.bank_connection(bank_account_id,instance_id,provider_account_key,status) VALUES(bank,instance,'test-provider-account','ACTIVE') RETURNING id INTO conn;
 INSERT INTO finance.bank_balance_snapshot(bank_account_id,connection_id,currency_code,balance_type,amount,retrieved_at,raw_amount,raw_unit_divisor,provider_snapshot_key,raw_record_id)
 VALUES(bank,conn,'NGN','PROVIDER_BALANCE',100,now(),10000,100,'snapshot-1',rawid);
 PERFORM pg_temp.expect_error('Bank units must reconcile',format('INSERT INTO finance.bank_balance_snapshot(bank_account_id,connection_id,currency_code,balance_type,amount,retrieved_at,raw_amount,raw_unit_divisor,provider_snapshot_key,raw_record_id) VALUES(%s,%s,''NGN'',''PROVIDER_BALANCE'',99,now(),10000,100,''bad-units'',%s)',bank,conn,rawid),'23514');
 PERFORM pg_temp.expect_error('Bank retry snapshot unique',format('INSERT INTO finance.bank_balance_snapshot(bank_account_id,connection_id,currency_code,balance_type,amount,retrieved_at,raw_amount,raw_unit_divisor,provider_snapshot_key,raw_record_id) VALUES(%s,%s,''NGN'',''PROVIDER_BALANCE'',100,now(),10000,100,''snapshot-1'',%s)',bank,conn,rawid),'23505');
 UPDATE finance.bank_connection SET last_error='Refresh failed',last_attempt_at=now() WHERE id=conn;
 PERFORM pg_temp.assert_ok('Refresh failure retains prior balance and error',(SELECT amount=100 AND last_error='Refresh failed' AND source_as_of IS NULL FROM finance.v_latest_bank_balance WHERE bank_account_id=bank));
 INSERT INTO finance.group_account(code,name) VALUES('TEST_GROUP_ACCOUNT','Test account') RETURNING id INTO groupacct;
 INSERT INTO finance.mapping_set(code,version_no) VALUES('TEST_OVERLAP',1) RETURNING id INTO mapset;
 INSERT INTO finance.account_mapping(mapping_set_id,account_id,group_account_id,effective_from,effective_to) VALUES(mapset,acct,groupacct,'2026-01-01','2026-03-31'),(mapset,acct,groupacct,'2026-03-01','2026-06-30');
 PERFORM pg_temp.expect_error('Overlapping effective mappings cannot be approved',format('UPDATE finance.mapping_set SET status=''APPROVED'',approved_by=%s,approved_at=now() WHERE id=%s',actor,mapset),'P0001');
 UPDATE finance.account_mapping SET effective_from='2026-04-01' WHERE mapping_set_id=mapset AND effective_from='2026-03-01';
 UPDATE finance.mapping_set SET status='APPROVED',approved_by=actor,approved_at=now() WHERE id=mapset;
 PERFORM pg_temp.expect_error('Approved account mappings immutable',format('UPDATE finance.account_mapping SET sign_multiplier=-1 WHERE mapping_set_id=%s',mapset),'P0001');
 INSERT INTO finance.mapping_set(code,version_no,status,approved_by,approved_at) VALUES('TEST_MAPPING',1,'APPROVED',actor,now()) RETURNING id INTO mapset;
 INSERT INTO finance.rule_set(code,version_no,definition,status,approved_by,approved_at) VALUES('TEST_RULES',1,'{}','APPROVED',actor,now()) RETURNING id INTO rules;
 INSERT INTO finance.report_version(series_id,report_id,layout_id,version_no,origin,created_by) VALUES(series,report,layout,3,'SYSTEM_CALCULATED',actor) RETURNING id INTO calcver;
 INSERT INTO finance.report_cell(version_id,layout_id,row_id,column_id,value_status,numeric_value) VALUES(calcver,layout,rw,col,'PRESENT',100);
 UPDATE finance.report_version SET status='SUBMITTED' WHERE id=calcver;
 PERFORM pg_temp.expect_error('Calculated report requires successful pinned run',format('SELECT finance.publish_report(%s,%s,''Test'')',calcver,actor),'P0001');
 UPDATE finance.report_version SET status='DRAFT' WHERE id=calcver;
 INSERT INTO finance.calculation_run(report_version_id,mapping_set_id,rule_set_id,engine_version,status) VALUES(calcver,mapset,rules,'test-only','RUNNING') RETURNING id INTO calcrun;
 INSERT INTO finance.calculation_input(calculation_run_id,trial_balance_id,purpose) VALUES(calcrun,tb,'PRIMARY');
 UPDATE finance.calculation_run SET status='SUCCEEDED',finished_at=now() WHERE id=calcrun;
 PERFORM pg_temp.expect_error('Successful calculation inputs immutable',format('DELETE FROM finance.calculation_input WHERE calculation_run_id=%s',calcrun),'P0001');
 UPDATE finance.report_version SET status='SUBMITTED' WHERE id=calcver;
 PERFORM finance.publish_report(calcver,actor,'Test engine output checked');
 PERFORM pg_temp.assert_ok('Calculated report publishes after pinned run',(SELECT version_id=calcver FROM finance.publication WHERE series_id=series));
 PERFORM pg_temp.expect_error('Audit events append-only','UPDATE audit.event SET action=''EDITED''','P0001');
 PERFORM pg_temp.assert_ok('Eight template placeholders only',(SELECT count(*)=8 FROM core.template_contract));
 PERFORM pg_temp.assert_ok('Fourteen workbook candidates remain provisional',(SELECT count(*)=14 FROM finance.report WHERE source_sheet IS NOT NULL AND catalogue_status='PENDING'));
 PERFORM pg_temp.assert_ok('No seeded external AI route',(SELECT bool_and(route='BLOCKED') FROM ai.route_policy));
 PERFORM pg_temp.assert_ok('No PUBLIC application schema usage',NOT EXISTS(
 SELECT 1 FROM pg_namespace n,LATERAL aclexplode(n.nspacl) a
 WHERE n.nspname IN ('core','iam','source','finance','audit','ai') AND a.grantee=0 AND a.privilege_type='USAGE'));
END $$;
SELECT * FROM test_result ORDER BY name;
ROLLBACK;
