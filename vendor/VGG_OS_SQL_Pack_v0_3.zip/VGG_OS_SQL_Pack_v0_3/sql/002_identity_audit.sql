-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

-- No passwords, local registration workflow or parallel directory administration.
CREATE TABLE iam.identity_provider(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL UNIQUE,
 issuer text NOT NULL, tenant_reference text NOT NULL DEFAULT '', configuration_status text NOT NULL DEFAULT 'PENDING'
 CHECK(configuration_status IN ('PENDING','CONFIRMED','DISABLED')), UNIQUE(issuer,tenant_reference));
CREATE TABLE iam.principal(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, provider_id bigint NOT NULL REFERENCES iam.identity_provider(id),
 external_subject text NOT NULL, display_name text, email text,
 principal_type text NOT NULL CHECK(principal_type IN ('USER','SERVICE')),
 active boolean NOT NULL DEFAULT true, UNIQUE(provider_id,external_subject));
CREATE TABLE iam.entitlement_mapping(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, provider_id bigint NOT NULL REFERENCES iam.identity_provider(id),
 external_entitlement text NOT NULL, action text NOT NULL CHECK(action IN ('VIEW','EXPORT','UPLOAD','APPROVE','ADMIN')),
 module_code text NOT NULL REFERENCES core.module(code), entity_id bigint REFERENCES core.entity(id),
 dataset_id bigint REFERENCES core.dataset(id), all_entities boolean NOT NULL DEFAULT false,
 effective_from timestamptz NOT NULL DEFAULT now(), effective_to timestamptz,
 CHECK((all_entities AND entity_id IS NULL) OR (NOT all_entities AND entity_id IS NOT NULL)),
 CHECK(effective_to IS NULL OR effective_to>effective_from));
COMMENT ON TABLE iam.entitlement_mapping IS 'Optional mapping from externally verified groups/app roles; backend evaluates combined scope. No active mappings seeded.';
CREATE TABLE audit.event(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, occurred_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 actor_id bigint REFERENCES iam.principal(id), db_actor text NOT NULL DEFAULT session_user,
 action text NOT NULL, object_type text NOT NULL, object_id text,
 outcome text NOT NULL DEFAULT 'SUCCESS' CHECK(outcome IN ('SUCCESS','FAILED','DENIED')),
 correlation_id text, details jsonb NOT NULL DEFAULT '{}');
CREATE TABLE audit.export_event(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, occurred_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 actor_id bigint NOT NULL REFERENCES iam.principal(id), report_version_id bigint,
 format text NOT NULL CHECK(format IN ('CSV','XLSX','PDF')), filters jsonb NOT NULL,
 row_count bigint CHECK(row_count>=0), outcome text NOT NULL CHECK(outcome IN ('SUCCESS','FAILED','DENIED')));
CREATE FUNCTION audit.deny_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'Evidence/history is append-only'; END $$;
CREATE TRIGGER immutable_event BEFORE UPDATE OR DELETE ON audit.event FOR EACH ROW EXECUTE FUNCTION audit.deny_mutation();
CREATE TRIGGER immutable_export BEFORE UPDATE OR DELETE ON audit.export_event FOR EACH ROW EXECUTE FUNCTION audit.deny_mutation();

COMMIT;
