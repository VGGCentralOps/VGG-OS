-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

CREATE TABLE finance.bank_account(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, entity_id bigint NOT NULL REFERENCES core.entity(id),
 code text NOT NULL UNIQUE, bank_name text NOT NULL, account_display text NOT NULL,
 currency_code text NOT NULL REFERENCES core.currency(code), active boolean NOT NULL DEFAULT true,
 UNIQUE(id,entity_id), UNIQUE(id,currency_code));
COMMENT ON COLUMN finance.bank_account.account_display IS 'Masked display identifier only. Full account numbers require protected storage, not numeric fields.';
CREATE TABLE finance.bank_connection(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, bank_account_id bigint NOT NULL REFERENCES finance.bank_account(id),
 instance_id bigint NOT NULL REFERENCES source.instance(id), provider_account_key text NOT NULL,
 consent_reference text, consent_expires_at timestamptz,
 status text NOT NULL CHECK(status IN ('PENDING','ACTIVE','REAUTHORISATION_REQUIRED','DISABLED')),
 last_attempt_at timestamptz, last_success_at timestamptz, last_error text,
 UNIQUE(instance_id,provider_account_key), UNIQUE(id,bank_account_id));
CREATE TABLE finance.bank_book_mapping(
 bank_account_id bigint NOT NULL, entity_id bigint NOT NULL, company_id bigint NOT NULL,
 external_bank_account_key text NOT NULL, gl_account_id bigint,
 FOREIGN KEY(bank_account_id,entity_id) REFERENCES finance.bank_account(id,entity_id),
 FOREIGN KEY(company_id,entity_id) REFERENCES source.company(id,entity_id),
 FOREIGN KEY(gl_account_id,entity_id) REFERENCES finance.account(id,entity_id),
 PRIMARY KEY(bank_account_id,company_id,external_bank_account_key));
CREATE TABLE finance.bank_balance_snapshot(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, bank_account_id bigint NOT NULL, connection_id bigint NOT NULL,
 currency_code text NOT NULL, balance_type text NOT NULL, amount numeric(28,8) NOT NULL,
 source_as_of timestamptz, retrieved_at timestamptz NOT NULL, refresh_confirmed_at timestamptz,
 raw_amount numeric(30,8) NOT NULL, raw_unit_divisor numeric NOT NULL CHECK(raw_unit_divisor>0),
 provider_snapshot_key text NOT NULL, raw_record_id bigint NOT NULL REFERENCES source.raw_record(id),
 FOREIGN KEY(connection_id,bank_account_id) REFERENCES finance.bank_connection(id,bank_account_id),
 FOREIGN KEY(bank_account_id,currency_code) REFERENCES finance.bank_account(id,currency_code),
 UNIQUE(connection_id,provider_snapshot_key,balance_type),
 CHECK(amount=raw_amount/raw_unit_divisor));
COMMENT ON TABLE finance.bank_balance_snapshot IS 'Only successful observations. Adapter confirms provider units/type; never store refresh failure as zero. Retrieval time alone does not prove provider freshness. No FX aggregation in this table.';
CREATE TABLE finance.bank_book_balance(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, bank_account_id bigint NOT NULL,
 as_of_date date NOT NULL, currency_code text NOT NULL, amount numeric(28,8) NOT NULL,
 run_id bigint NOT NULL REFERENCES source.ingestion_run(id), source_reference text NOT NULL,
 FOREIGN KEY(bank_account_id,currency_code) REFERENCES finance.bank_account(id,currency_code),
 UNIQUE(bank_account_id,as_of_date,run_id));
CREATE TABLE finance.submission_requirement(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, dataset_id bigint NOT NULL REFERENCES core.dataset(id),
 entity_id bigint NOT NULL REFERENCES core.entity(id), period_id bigint NOT NULL REFERENCES core.period(id),
 deadline_at timestamptz NOT NULL, business_timezone text NOT NULL DEFAULT 'Africa/Lagos',
 counting_method text CHECK(counting_method IN ('CALENDAR_DAY','BUSINESS_DAY','ELAPSED_HOURS')),
 UNIQUE(dataset_id,entity_id,period_id));
CREATE TABLE finance.submission_event(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, requirement_id bigint NOT NULL REFERENCES finance.submission_requirement(id),
 submitted_at timestamptz NOT NULL, received_at timestamptz NOT NULL DEFAULT now(),
 source_file_id bigint REFERENCES source.file(id), source_event_reference text NOT NULL UNIQUE,
 event_type text NOT NULL CHECK(event_type IN ('INITIAL','CORRECTION')), actor_id bigint REFERENCES iam.principal(id), evidence_reference text NOT NULL);
COMMENT ON TABLE finance.submission_event IS 'Capture true submission evidence, not database ingestion time. Finance confirms first/latest accepted event, day-counting and scoring before heat-map automation.';
CREATE TABLE finance.incubated_expense_allocation(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, beneficiary_entity_id bigint NOT NULL REFERENCES core.entity(id),
 payer_entity_id bigint NOT NULL REFERENCES core.entity(id), expense_date date NOT NULL,
 category text NOT NULL, amount numeric(28,8) NOT NULL, currency_code text NOT NULL REFERENCES core.currency(code),
 payment_reference text NOT NULL, allocation_reference text NOT NULL UNIQUE,
 evidence_file_id bigint NOT NULL REFERENCES source.file(id), approved_by bigint REFERENCES iam.principal(id), approved_at timestamptz,
 CHECK((approved_by IS NULL)=(approved_at IS NULL)));
COMMENT ON TABLE finance.incubated_expense_allocation IS 'Controlled imports of the existing log; not a new expense request or payment workflow. Beneficiary cannot be inferred from vendor narration alone.';
CREATE INDEX bank_balance_time ON finance.bank_balance_snapshot(bank_account_id,retrieved_at DESC);


-- Supporting facts from supplied report structures; optional for Delivery 1 prepared-output imports.
CREATE TABLE finance.intercompany_position(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, book_entity_id bigint NOT NULL REFERENCES core.entity(id),
 counterparty_entity_id bigint NOT NULL REFERENCES core.entity(id), period_id bigint NOT NULL REFERENCES core.period(id),
 currency_code text NOT NULL REFERENCES core.currency(code), receivable numeric(28,8) NOT NULL CHECK(receivable>=0),
 payable numeric(28,8) NOT NULL CHECK(payable>=0), net_receivable numeric(28,8) GENERATED ALWAYS AS (receivable-payable) STORED,
 run_id bigint NOT NULL REFERENCES source.ingestion_run(id), file_record_id bigint REFERENCES source.file_record(id),
 CHECK(book_entity_id<>counterparty_entity_id), UNIQUE(book_entity_id,counterparty_entity_id,period_id,currency_code,run_id));
COMMENT ON TABLE finance.intercompany_position IS 'Book entity and counterparty are explicit. Do not auto-eliminate or net across currencies; agree matching, differences and consolidation rules with Finance.';
CREATE TABLE finance.debt_facility(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, entity_id bigint NOT NULL REFERENCES core.entity(id),
 facility_code text NOT NULL UNIQUE, lender_name text NOT NULL, currency_code text NOT NULL REFERENCES core.currency(code),
 agreement_file_id bigint REFERENCES source.file(id), UNIQUE(id,currency_code));
CREATE TABLE finance.debt_schedule_line(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, facility_id bigint NOT NULL, currency_code text NOT NULL,
 due_date date NOT NULL, basis text NOT NULL CHECK(basis IN ('ACTUAL','SCHEDULED','FORECAST')),
 opening_principal numeric(28,8), accrued_interest numeric(28,8), principal_payment numeric(28,8),
 total_payment numeric(28,8), closing_balance numeric(28,8), run_id bigint NOT NULL REFERENCES source.ingestion_run(id),
 file_record_id bigint REFERENCES source.file_record(id),
 FOREIGN KEY(facility_id,currency_code) REFERENCES finance.debt_facility(id,currency_code),
 UNIQUE(facility_id,due_date,basis,run_id));
COMMENT ON TABLE finance.debt_schedule_line IS 'Imported schedule observations. No inferred interest, capitalisation, drawdown or repayment formula; supplied figures are reconciled without silently repairing them.';
CREATE TABLE finance.partner_expense(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, payer_entity_id bigint NOT NULL REFERENCES core.entity(id),
 partner_reference text NOT NULL, expense_date date NOT NULL, category text, description text,
 payment_method text, payment_reference text, payment_status text,
 amount numeric(28,8) NOT NULL, currency_code text NOT NULL REFERENCES core.currency(code),
 run_id bigint NOT NULL REFERENCES source.ingestion_run(id), file_record_id bigint NOT NULL REFERENCES source.file_record(id),
 UNIQUE(run_id,file_record_id,currency_code));
COMMENT ON TABLE finance.partner_expense IS 'Restricted supporting facts. NGN and USD are separate observations, not amounts to sum without an approved FX rule. Authorise this dataset separately from general group reports.';
COMMIT;
