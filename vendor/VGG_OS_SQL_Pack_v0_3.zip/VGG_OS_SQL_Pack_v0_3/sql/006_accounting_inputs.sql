-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

-- Provisional standard accounting contracts; align with actual templates before production loading.
CREATE TABLE finance.account(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, entity_id bigint NOT NULL REFERENCES core.entity(id),
 account_code text NOT NULL, account_name text NOT NULL, account_type text,
 source_company_id bigint, active boolean NOT NULL DEFAULT true,
 FOREIGN KEY(source_company_id,entity_id) REFERENCES source.company(id,entity_id),
 UNIQUE(entity_id,account_code), UNIQUE(id,entity_id));
CREATE TABLE finance.group_account(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL UNIQUE, name text NOT NULL,
 account_type text, parent_id bigint REFERENCES finance.group_account(id), CHECK(parent_id IS NULL OR parent_id<>id));
CREATE TABLE finance.mapping_set(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL, version_no integer NOT NULL CHECK(version_no>0),
 status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','APPROVED','RETIRED')),
 approved_by bigint REFERENCES iam.principal(id), approved_at timestamptz,
 UNIQUE(code,version_no), CHECK(status<>'APPROVED' OR (approved_by IS NOT NULL AND approved_at IS NOT NULL)));
CREATE TABLE finance.account_mapping(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, mapping_set_id bigint NOT NULL REFERENCES finance.mapping_set(id),
 account_id bigint NOT NULL REFERENCES finance.account(id), group_account_id bigint NOT NULL REFERENCES finance.group_account(id),
 sign_multiplier smallint NOT NULL DEFAULT 1 CHECK(sign_multiplier IN (-1,1)),
 effective_from date NOT NULL, effective_to date,
 UNIQUE(mapping_set_id,account_id,effective_from), CHECK(effective_to IS NULL OR effective_to>=effective_from));
COMMENT ON TABLE finance.account_mapping IS 'No account mapping is seeded. Validate overlapping effective ranges and completeness before approval; pin mapping_set in report runs.';
CREATE TABLE finance.trial_balance(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, entity_id bigint NOT NULL REFERENCES core.entity(id),
 period_id bigint NOT NULL REFERENCES core.period(id), currency_code text NOT NULL REFERENCES core.currency(code),
 version_no integer NOT NULL CHECK(version_no>0), basis text NOT NULL
 CHECK(basis IN ('CLOSING','MONTH_MOVEMENT','YTD_MOVEMENT','OPENING')),
 source_kind text NOT NULL CHECK(source_kind IN ('BC','SUBSIDIARY_UPLOAD')),
 run_id bigint NOT NULL REFERENCES source.ingestion_run(id), status text NOT NULL DEFAULT 'DRAFT'
 CHECK(status IN ('DRAFT','VALIDATED','APPROVED','REJECTED')),
 month_end_ready boolean NOT NULL DEFAULT false, approved_by bigint REFERENCES iam.principal(id), approved_at timestamptz,
 UNIQUE(entity_id,period_id,currency_code,basis,source_kind,version_no), UNIQUE(id,entity_id),
 UNIQUE(id,entity_id,period_id,currency_code,basis),
 CHECK(status<>'APPROVED' OR (approved_by IS NOT NULL AND approved_at IS NOT NULL AND month_end_ready)));
CREATE TABLE finance.trial_balance_line(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, trial_balance_id bigint NOT NULL, entity_id bigint NOT NULL,
 account_id bigint NOT NULL, organisation_unit_id bigint, dimension_key text NOT NULL DEFAULT '',
 dimensions jsonb NOT NULL DEFAULT '{}', debit numeric(28,8) NOT NULL CHECK(debit>=0),
 credit numeric(28,8) NOT NULL CHECK(credit>=0), signed_amount numeric(28,8) GENERATED ALWAYS AS (debit-credit) STORED,
 raw_record_id bigint REFERENCES source.raw_record(id), file_record_id bigint REFERENCES source.file_record(id),
 FOREIGN KEY(trial_balance_id,entity_id) REFERENCES finance.trial_balance(id,entity_id),
 FOREIGN KEY(account_id,entity_id) REFERENCES finance.account(id,entity_id),
 FOREIGN KEY(organisation_unit_id,entity_id) REFERENCES core.organisation_unit(id,entity_id),
 UNIQUE NULLS NOT DISTINCT(trial_balance_id,account_id,organisation_unit_id,dimension_key));
COMMENT ON TABLE finance.trial_balance_line IS 'Canonical sign: debit positive, credit negative. Upload adapter must declare incoming convention. Do not sum closing balances across months.';
CREATE TABLE finance.reporting_source_selection(
 entity_id bigint NOT NULL, period_id bigint NOT NULL, currency_code text NOT NULL, basis text NOT NULL,
 trial_balance_id bigint NOT NULL, selected_by bigint NOT NULL REFERENCES iam.principal(id), selected_at timestamptz NOT NULL DEFAULT now(), reason text NOT NULL,
 PRIMARY KEY(entity_id,period_id,currency_code,basis),
 FOREIGN KEY(trial_balance_id,entity_id,period_id,currency_code,basis)
 REFERENCES finance.trial_balance(id,entity_id,period_id,currency_code,basis));
CREATE TABLE finance.source_selection_history(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, occurred_at timestamptz NOT NULL DEFAULT now(),
 entity_id bigint NOT NULL REFERENCES core.entity(id), period_id bigint NOT NULL REFERENCES core.period(id),
 old_trial_balance_id bigint REFERENCES finance.trial_balance(id), new_trial_balance_id bigint NOT NULL REFERENCES finance.trial_balance(id),
 actor_id bigint NOT NULL REFERENCES iam.principal(id), reason text NOT NULL);
CREATE FUNCTION finance.guard_source_selection() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM id FROM finance.trial_balance WHERE id=NEW.trial_balance_id AND status='APPROVED' FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Selected TB must be approved'; END IF;
 INSERT INTO finance.source_selection_history(entity_id,period_id,old_trial_balance_id,new_trial_balance_id,actor_id,reason)
 VALUES(NEW.entity_id,NEW.period_id,CASE WHEN TG_OP='UPDATE' THEN OLD.trial_balance_id ELSE NULL END,NEW.trial_balance_id,NEW.selected_by,NEW.reason);
 RETURN NEW;
END $$;
CREATE TRIGGER selection_guard BEFORE INSERT OR UPDATE ON finance.reporting_source_selection FOR EACH ROW EXECUTE FUNCTION finance.guard_source_selection();
CREATE TRIGGER selection_history_guard BEFORE UPDATE OR DELETE ON finance.source_selection_history FOR EACH ROW EXECUTE FUNCTION audit.deny_mutation();
CREATE TABLE finance.gl_entry(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, company_id bigint NOT NULL, entity_id bigint NOT NULL,
 source_entry_key text NOT NULL, source_version text NOT NULL, account_id bigint NOT NULL,
 posting_date date NOT NULL, document_reference text, currency_code text NOT NULL REFERENCES core.currency(code),
 amount numeric(28,8) NOT NULL, dimensions jsonb NOT NULL DEFAULT '{}',
 raw_record_id bigint NOT NULL REFERENCES source.raw_record(id), source_deleted boolean NOT NULL DEFAULT false,
 FOREIGN KEY(company_id,entity_id) REFERENCES source.company(id,entity_id),
 FOREIGN KEY(account_id,entity_id) REFERENCES finance.account(id,entity_id),
 UNIQUE(company_id,source_entry_key));
CREATE INDEX gl_posting ON finance.gl_entry(entity_id,posting_date,account_id);
COMMENT ON TABLE finance.gl_entry IS 'Current normalised source projection; upsert by company/source key. Raw records preserve successive extraction versions. No implicit report publication.';
CREATE TABLE finance.rule_set(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL, version_no integer NOT NULL CHECK(version_no>0),
 definition jsonb NOT NULL, status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','APPROVED','RETIRED')),
 approved_by bigint REFERENCES iam.principal(id), approved_at timestamptz,
 UNIQUE(code,version_no), CHECK(status<>'APPROVED' OR (approved_by IS NOT NULL AND approved_at IS NOT NULL)));
CREATE TABLE finance.calculation_run(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, report_version_id bigint NOT NULL UNIQUE REFERENCES finance.report_version(id),
 mapping_set_id bigint NOT NULL REFERENCES finance.mapping_set(id), rule_set_id bigint NOT NULL REFERENCES finance.rule_set(id),
 engine_version text NOT NULL, status text NOT NULL CHECK(status IN ('RUNNING','SUCCEEDED','FAILED')),
 started_at timestamptz NOT NULL DEFAULT now(), finished_at timestamptz);
CREATE TABLE finance.calculation_input(
 calculation_run_id bigint NOT NULL REFERENCES finance.calculation_run(id), trial_balance_id bigint NOT NULL REFERENCES finance.trial_balance(id),
 purpose text NOT NULL CHECK(purpose IN ('PRIMARY','SUPPLEMENT','COMPARISON')),
 PRIMARY KEY(calculation_run_id,trial_balance_id));
CREATE TABLE finance.fx_rate(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, from_currency text NOT NULL REFERENCES core.currency(code),
 to_currency text NOT NULL REFERENCES core.currency(code), rate_date date NOT NULL,
 rate_type text NOT NULL CHECK(rate_type IN ('CLOSING','AVERAGE','HISTORICAL','TRANSACTION')),
 rate numeric(28,12) NOT NULL CHECK(rate>0), source_reference text NOT NULL,
 approved_by bigint NOT NULL REFERENCES iam.principal(id), approved_at timestamptz NOT NULL,
 UNIQUE(from_currency,to_currency,rate_date,rate_type,source_reference), CHECK(from_currency<>to_currency));
CREATE TABLE finance.calculation_fx_input(
 calculation_run_id bigint NOT NULL REFERENCES finance.calculation_run(id), fx_rate_id bigint NOT NULL REFERENCES finance.fx_rate(id),
 PRIMARY KEY(calculation_run_id,fx_rate_id));
CREATE TABLE finance.cell_lineage(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, cell_id bigint NOT NULL REFERENCES finance.report_cell(id),
 trial_balance_line_id bigint REFERENCES finance.trial_balance_line(id), raw_record_id bigint REFERENCES source.raw_record(id),
 file_record_id bigint REFERENCES source.file_record(id), calculation_run_id bigint REFERENCES finance.calculation_run(id),
 transformation_reference text, CHECK(num_nonnulls(trial_balance_line_id,raw_record_id,file_record_id,calculation_run_id)=1));

COMMIT;
