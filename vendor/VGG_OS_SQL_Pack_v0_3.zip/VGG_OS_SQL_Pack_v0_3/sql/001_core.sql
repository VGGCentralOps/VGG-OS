-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

CREATE SCHEMA core; CREATE SCHEMA iam; CREATE SCHEMA source; CREATE SCHEMA finance;
CREATE SCHEMA audit; CREATE SCHEMA ai;
CREATE SCHEMA hr; CREATE SCHEMA ops; CREATE SCHEMA risk; CREATE SCHEMA legal; CREATE SCHEMA product;
CREATE TABLE core.schema_version(version text PRIMARY KEY, installed_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE core.module(code text PRIMARY KEY, name text NOT NULL, active boolean NOT NULL DEFAULT true);
CREATE TABLE core.currency(code text PRIMARY KEY CHECK(code ~ '^[A-Z]{3}$'), name text NOT NULL, decimals smallint NOT NULL DEFAULT 2 CHECK(decimals BETWEEN 0 AND 6));
CREATE TABLE core.entity(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL UNIQUE, name text NOT NULL,
 entity_type text NOT NULL CHECK(entity_type IN ('GROUP','LEGAL_ENTITY','INCUBATED','OTHER')),
 parent_id bigint REFERENCES core.entity(id), functional_currency text REFERENCES core.currency(code),
 country_code text CHECK(country_code ~ '^[A-Z]{2}$'), active boolean NOT NULL DEFAULT true,
 CHECK(parent_id IS NULL OR parent_id<>id));
CREATE TABLE core.entity_alias(alias text PRIMARY KEY, entity_id bigint NOT NULL REFERENCES core.entity(id));
CREATE TABLE core.organisation_unit(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, entity_id bigint NOT NULL REFERENCES core.entity(id),
 code text NOT NULL, name text NOT NULL, UNIQUE(entity_id,code), UNIQUE(id,entity_id));
CREATE TABLE core.period(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL UNIQUE, name text NOT NULL,
 kind text NOT NULL CHECK(kind IN ('DAY','WEEK','MONTH','QUARTER','YEAR','YTD','CUSTOM')),
 start_date date NOT NULL, end_date date NOT NULL, fiscal_year integer NOT NULL,
 CHECK(end_date>=start_date));
CREATE TABLE core.dataset(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL UNIQUE, name text NOT NULL,
 module_code text NOT NULL REFERENCES core.module(code), business_owner text,
 sensitivity text NOT NULL DEFAULT 'CONFIDENTIAL' CHECK(sensitivity IN ('PUBLIC','INTERNAL','CONFIDENTIAL','RESTRICTED')),
 definition_status text NOT NULL DEFAULT 'DRAFT' CHECK(definition_status IN ('DRAFT','PENDING','APPROVED','RETIRED')),
 grain_description text, active boolean NOT NULL DEFAULT true);
CREATE TABLE core.unit(code text PRIMARY KEY, name text NOT NULL);
CREATE TABLE core.scenario(code text PRIMARY KEY, name text NOT NULL);
COMMENT ON SCHEMA hr IS 'Reserved only; no confirmed HR input model is assumed.';
COMMENT ON SCHEMA ops IS 'Reserved for future domain migrations.';
COMMENT ON SCHEMA risk IS 'Reserved for future domain migrations.';
COMMENT ON SCHEMA legal IS 'Reserved for future domain migrations.';
COMMENT ON SCHEMA product IS 'Reserved for future domain migrations.';

COMMIT;
