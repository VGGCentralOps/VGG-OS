-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

-- These are trusted BACKEND views, not automatic per-user/entity security boundaries.
CREATE VIEW finance.v_published_cells AS
SELECT r.id AS report_id,r.code AS report_code,r.name AS report_name,
 s.id AS series_id,s.period_id AS publication_period_id,s.scope_entity_id,s.variant_code,
 v.id AS version_id,v.version_no,v.origin,v.approved_at,p.published_at,v.layout_id,
 rw.id AS row_id,rw.code AS row_code,rw.label AS row_label,rw.row_type,rw.display_order AS row_order,
 col.id AS column_id,col.code AS column_code,col.label AS column_label,col.display_order AS column_order,
 col.period_id AS observation_period_id,col.scenario_code,col.value_type,
 coalesce(c.unit_code,col.unit_code) AS unit_code,coalesce(c.currency_code,col.currency_code) AS currency_code,
 col.display_scale,col.decimals,c.id AS cell_id,c.value_status,c.numeric_value,
 c.numeric_value/col.display_scale AS display_numeric_value,c.text_value,c.date_value,c.boolean_value,
 coalesce(c.entity_id,col.entity_id,rw.entity_id) AS observation_entity_id,c.organisation_unit_id,
 v.source_file_id,c.source_file_record_id,c.source_raw_record_id
FROM finance.publication p
JOIN finance.report_version v ON v.id=p.version_id AND v.status='APPROVED'
JOIN finance.report_series s ON s.id=v.series_id
JOIN finance.report r ON r.id=s.report_id
JOIN finance.layout_row rw ON rw.layout_id=v.layout_id
JOIN finance.report_cell c ON c.version_id=v.id AND c.row_id=rw.id
JOIN finance.layout_column col ON col.id=c.column_id;
CREATE VIEW finance.v_approved_history_cells AS
SELECT v.series_id,v.version_no,v.status,v.origin,v.approved_at,c.*
FROM finance.report_version v JOIN finance.report_cell c ON c.version_id=v.id
WHERE v.status IN ('APPROVED','SUPERSEDED');
CREATE VIEW finance.v_selected_tb AS
SELECT s.entity_id,s.period_id,s.currency_code,s.basis,s.trial_balance_id,l.id AS trial_balance_line_id,
 l.account_id,l.organisation_unit_id,l.dimension_key,l.debit,l.credit,l.signed_amount
FROM finance.reporting_source_selection s JOIN finance.trial_balance t ON t.id=s.trial_balance_id AND t.status='APPROVED'
JOIN finance.trial_balance_line l ON l.trial_balance_id=t.id;
CREATE VIEW finance.v_latest_bank_balance AS
SELECT DISTINCT ON (b.bank_account_id,b.balance_type)
 a.entity_id,a.code AS account_code,a.bank_name,a.account_display,b.*,
 cn.status AS connection_status,cn.last_attempt_at,cn.last_success_at,cn.last_error
FROM finance.bank_balance_snapshot b JOIN finance.bank_account a ON a.id=b.bank_account_id
JOIN finance.bank_connection cn ON cn.id=b.connection_id
ORDER BY b.bank_account_id,b.balance_type,b.retrieved_at DESC,b.id DESC;
COMMENT ON VIEW finance.v_latest_bank_balance IS 'One last successful observation per account/type. Backend must display unknown/stale source time, connection failures and missing account coverage; no universal freshness threshold assumed.';
CREATE VIEW core.v_physical_dictionary AS
SELECT table_schema,table_name,column_name,data_type,is_nullable,column_default
FROM information_schema.columns WHERE table_schema IN ('core','iam','source','finance','audit','ai','hr','ops','risk','legal','product');
CREATE VIEW source.v_run_status AS
SELECT r.id,r.status,r.stream_id,r.file_id,r.started_at,r.finished_at,r.rows_read,r.rows_accepted,r.rows_rejected,r.error_summary,
 s.endpoint_code,c.entity_id,i.code AS instance_code
FROM source.ingestion_run r LEFT JOIN source.sync_stream s ON s.id=r.stream_id
LEFT JOIN source.company c ON c.id=s.company_id LEFT JOIN source.instance i ON i.id=c.instance_id;

COMMIT;
