-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

-- Installer owns objects. Provision separate, private backend logins via IT; never connect browsers directly.
REVOKE ALL ON SCHEMA core,iam,source,finance,audit,ai,hr,ops,risk,legal,product FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA core,iam,source,finance,audit,ai FROM PUBLIC;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA core,iam,source,finance,audit,ai FROM PUBLIC;
REVOKE EXECUTE ON ALL FUNCTIONS IN SCHEMA core,iam,source,finance,audit,ai FROM PUBLIC;
-- Default privileges apply to objects subsequently created BY THIS installer role.
ALTER DEFAULT PRIVILEGES IN SCHEMA core,iam,source,finance,audit,ai REVOKE ALL ON TABLES FROM PUBLIC;
ALTER DEFAULT PRIVILEGES IN SCHEMA core,iam,source,finance,audit,ai REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;
-- Grant no access until Engineering confirms identity, backend roles and entity/report scope rules.
-- Table owner/superuser is not a runtime account. This is a server-authorised model, not RLS.

COMMIT;
