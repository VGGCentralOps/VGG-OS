-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

INSERT INTO core.module(code,name) VALUES ('FINANCE','Finance'),('HR','People'),('OPERATIONS','Operations'),('RISK','Risk'),('LEGAL','Legal'),('PRODUCT','Product');
INSERT INTO core.currency(code,name) VALUES ('NGN','Nigerian naira'),('USD','US dollar'),('GBP','Pound sterling'),('EUR','Euro'),('KES','Kenyan shilling');
INSERT INTO core.unit(code,name) VALUES ('MONEY','Currency amount'),('PERCENT','Percentage points'),('DAYS','Days'),('COUNT','Count'),('RATIO','Ratio'),('TEXT','Text'),('DATE','Date'),('BOOLEAN','Boolean');
INSERT INTO core.scenario(code,name) VALUES ('ACTUAL','Actual'),('BUDGET','Budget'),('FORECAST','Forecast');
-- No guessed subsidiary functional currencies, bank accounts, permissions or IAM provider seeded.
INSERT INTO core.entity(code,name,entity_type) VALUES ('VGG_GROUP','VGG Group','GROUP');
INSERT INTO source.system(code,name,kind) VALUES ('BUSINESS_CENTRAL','Business Central','ERP'),('MONO','Mono','BANK_API'),('FINANCE_WORKBOOK','Finance reporting workbook','WORKBOOK'),('SUPPORTING_DOCUMENTS','Supporting evidence','DOCUMENT_STORE');
INSERT INTO core.dataset(code,name,module_code,definition_status) VALUES
 ('FINANCE_GROUP_REPORTS','Prepared Finance group report outputs','FINANCE','DRAFT'),
 ('CHART_OF_ACCOUNTS','Chart of accounts input template','FINANCE','PENDING'),
 ('TRIAL_BALANCE','Trial balance input template','FINANCE','PENDING'),
 ('TEMPLATE_PENDING_03','Input template 3: awaiting definition','FINANCE','PENDING'),
 ('TEMPLATE_PENDING_04','Input template 4: awaiting definition','FINANCE','PENDING'),
 ('TEMPLATE_PENDING_05','Input template 5: awaiting definition','FINANCE','PENDING'),
 ('TEMPLATE_PENDING_06','Input template 6: awaiting definition','FINANCE','PENDING'),
 ('TEMPLATE_PENDING_07','Input template 7: awaiting definition','FINANCE','PENDING'),
 ('TEMPLATE_PENDING_08','Input template 8: awaiting definition','FINANCE','PENDING'),
 ('BANK_BALANCES','Bank balance observations','FINANCE','DRAFT');
INSERT INTO core.template_contract(dataset_id,version_no)
SELECT id,1 FROM core.dataset WHERE code IN ('CHART_OF_ACCOUNTS','TRIAL_BALANCE') OR code LIKE 'TEMPLATE_PENDING_%';
INSERT INTO ai.route_policy(sensitivity) VALUES ('PUBLIC'),('INTERNAL'),('CONFIDENTIAL'),('RESTRICTED');
INSERT INTO core.schema_version(version) VALUES ('0.3.0');

COMMIT;
