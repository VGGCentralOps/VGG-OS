-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

CREATE FUNCTION finance.guard_layout() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF OLD.status='APPROVED' THEN RAISE EXCEPTION 'Approved layout is immutable; create a new version'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER layout_guard BEFORE UPDATE OR DELETE ON finance.layout FOR EACH ROW EXECUTE FUNCTION finance.guard_layout();
CREATE FUNCTION finance.guard_layout_member() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE k bigint; st text; BEGIN
 IF TG_OP='UPDATE' AND NEW.layout_id<>OLD.layout_id THEN RAISE EXCEPTION 'Cannot move layout member'; END IF;
 IF TG_OP='DELETE' THEN k:=OLD.layout_id; ELSE k:=NEW.layout_id; END IF;
 SELECT status INTO st FROM finance.layout WHERE id=k FOR UPDATE;
 IF st='APPROVED' THEN RAISE EXCEPTION 'Approved layout members are immutable'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER row_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.layout_row FOR EACH ROW EXECUTE FUNCTION finance.guard_layout_member();
CREATE TRIGGER column_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.layout_column FOR EACH ROW EXECUTE FUNCTION finance.guard_layout_member();
CREATE FUNCTION finance.guard_version() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='INSERT' THEN
  IF NEW.status<>'DRAFT' THEN RAISE EXCEPTION 'New version must be DRAFT'; END IF;
  RETURN NEW;
 END IF;
 IF OLD.status IN ('APPROVED','SUPERSEDED') THEN
  IF TG_OP='DELETE' THEN RAISE EXCEPTION 'Approved history cannot be deleted'; END IF;
  IF NOT(OLD.status='APPROVED' AND NEW.status='SUPERSEDED' AND
   (to_jsonb(NEW)-'status')=(to_jsonb(OLD)-'status')) THEN RAISE EXCEPTION 'Approved history is immutable'; END IF;
 END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF;
 IF NEW.series_id<>OLD.series_id OR NEW.report_id<>OLD.report_id OR NEW.layout_id<>OLD.layout_id OR NEW.version_no<>OLD.version_no
 THEN RAISE EXCEPTION 'Version identity is immutable'; END IF;
 IF NEW.status IN ('APPROVED','SUPERSEDED') AND OLD.status NOT IN ('SUBMITTED','APPROVED')
 THEN RAISE EXCEPTION 'Submit before approval'; END IF;
 IF NEW.status='APPROVED' AND NOT EXISTS(SELECT 1 FROM finance.layout WHERE id=NEW.layout_id AND status='APPROVED')
 THEN RAISE EXCEPTION 'Layout must be approved'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER version_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.report_version FOR EACH ROW EXECUTE FUNCTION finance.guard_version();
CREATE FUNCTION finance.guard_cell() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE k bigint; st text; typ text; effective_unit text; effective_currency text; BEGIN
 IF TG_OP='UPDATE' AND (NEW.version_id<>OLD.version_id OR NEW.layout_id<>OLD.layout_id)
 THEN RAISE EXCEPTION 'Cannot move cells between versions'; END IF;
 IF TG_OP='DELETE' THEN k:=OLD.version_id; ELSE k:=NEW.version_id; END IF;
 SELECT status INTO st FROM finance.report_version WHERE id=k FOR UPDATE;
 IF st<>'DRAFT' THEN RAISE EXCEPTION 'Only DRAFT cells may be edited'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF;
 SELECT value_type,coalesce(NEW.unit_code,unit_code),coalesce(NEW.currency_code,currency_code) INTO typ,effective_unit,effective_currency FROM finance.layout_column WHERE id=NEW.column_id;
 IF NEW.value_status='PRESENT' AND typ='NUMBER' AND effective_unit='MONEY' AND effective_currency IS NULL
 THEN RAISE EXCEPTION 'Monetary values require an explicit currency'; END IF;
 IF NEW.value_status='PRESENT' AND typ='NUMBER' AND effective_unit<>'MONEY' AND effective_currency IS NOT NULL
 THEN RAISE EXCEPTION 'Non-money numbers must not carry a currency'; END IF;
 IF NEW.value_status='PRESENT' AND NOT (
 (typ='NUMBER' AND NEW.numeric_value IS NOT NULL) OR (typ='TEXT' AND NEW.text_value IS NOT NULL) OR
 (typ='DATE' AND NEW.date_value IS NOT NULL) OR (typ='BOOLEAN' AND NEW.boolean_value IS NOT NULL))
 THEN RAISE EXCEPTION 'Cell type does not match column type'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER cell_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.report_cell FOR EACH ROW EXECUTE FUNCTION finance.guard_cell();
CREATE FUNCTION finance.guard_adjustment() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE k bigint; BEGIN
 IF TG_OP='UPDATE' AND NEW.cell_id<>OLD.cell_id THEN RAISE EXCEPTION 'Cannot move adjustment'; END IF;
 IF TG_OP='DELETE' THEN k:=OLD.cell_id; ELSE k:=NEW.cell_id; END IF;
 PERFORM v.id FROM finance.report_version v JOIN finance.report_cell c ON c.version_id=v.id WHERE c.id=k AND v.status='DRAFT' FOR UPDATE OF v;
 IF NOT FOUND THEN RAISE EXCEPTION 'Adjustments require a DRAFT report version'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER adjustment_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.cell_adjustment FOR EACH ROW EXECUTE FUNCTION finance.guard_adjustment();
CREATE FUNCTION finance.guard_publication() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM finance.report_version WHERE id=NEW.version_id AND series_id=NEW.series_id AND status='APPROVED')
 THEN RAISE EXCEPTION 'Only approved version can be published'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER publication_guard BEFORE INSERT OR UPDATE ON finance.publication FOR EACH ROW EXECUTE FUNCTION finance.guard_publication();
-- Trusted backend must verify approver authority, separation-of-duties policy and scope first.
-- Invoker rights, not SECURITY DEFINER. Approval is explicit; never inferred from file arrival.
CREATE FUNCTION finance.publish_report(p_version bigint,p_actor bigint,p_note text) RETURNS void LANGUAGE plpgsql AS $$
DECLARE v finance.report_version; old_id bigint; BEGIN
 SELECT * INTO STRICT v FROM finance.report_version WHERE id=p_version;
 PERFORM 1 FROM finance.report_series WHERE id=v.series_id FOR UPDATE;
 SELECT * INTO STRICT v FROM finance.report_version WHERE id=p_version FOR UPDATE;
 IF v.status<>'SUBMITTED' THEN RAISE EXCEPTION 'Report must be SUBMITTED'; END IF;
 IF NOT EXISTS(SELECT 1 FROM iam.principal WHERE id=p_actor AND active) THEN RAISE EXCEPTION 'Inactive actor'; END IF;
 IF NOT EXISTS(SELECT 1 FROM finance.report_cell WHERE version_id=p_version) THEN RAISE EXCEPTION 'Empty report'; END IF;
 IF v.ingestion_run_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM source.ingestion_run WHERE id=v.ingestion_run_id AND status='SUCCEEDED')
 THEN RAISE EXCEPTION 'Ingestion run must succeed'; END IF;
 IF v.origin='SYSTEM_CALCULATED' AND NOT EXISTS(SELECT 1 FROM finance.calculation_run WHERE report_version_id=p_version AND status='SUCCEEDED')
 THEN RAISE EXCEPTION 'Successful pinned calculation required'; END IF;
 SELECT version_id INTO old_id FROM finance.publication WHERE series_id=v.series_id;
 UPDATE finance.report_version SET status='APPROVED',approved_by=p_actor,approved_at=clock_timestamp(),approval_note=p_note WHERE id=p_version;
 INSERT INTO finance.publication(series_id,version_id,published_by) VALUES(v.series_id,p_version,p_actor)
 ON CONFLICT(series_id) DO UPDATE SET version_id=EXCLUDED.version_id,published_by=EXCLUDED.published_by,published_at=clock_timestamp();
 IF old_id IS NOT NULL THEN UPDATE finance.report_version SET status='SUPERSEDED' WHERE id=old_id; END IF;
 INSERT INTO audit.event(actor_id,action,object_type,object_id,details)
 VALUES(p_actor,'REPORT_PUBLISHED','REPORT_VERSION',p_version::text,jsonb_build_object('previous_version_id',old_id,'note',p_note));
END $$;

COMMIT;
