-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

CREATE TABLE core.template_contract(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, dataset_id bigint NOT NULL REFERENCES core.dataset(id),
 version_no integer NOT NULL CHECK(version_no>0), status text NOT NULL DEFAULT 'PENDING'
 CHECK(status IN ('PENDING','DRAFT','APPROVED','RETIRED')), row_grain text, submission_frequency text,
 evidence_file_id bigint REFERENCES source.file(id), business_approved_by bigint REFERENCES iam.principal(id),
 business_approved_at timestamptz, technical_verified_by bigint REFERENCES iam.principal(id), technical_verified_at timestamptz,
 UNIQUE(dataset_id,version_no), CHECK(status<>'APPROVED' OR (business_approved_by IS NOT NULL AND business_approved_at IS NOT NULL)));
CREATE TABLE core.field_definition(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, dataset_id bigint NOT NULL REFERENCES core.dataset(id),
 code text NOT NULL, version_no integer NOT NULL CHECK(version_no>0), business_name text NOT NULL, definition text,
 logical_type text NOT NULL, required boolean NOT NULL DEFAULT false, allowed_values jsonb,
 unit_code text REFERENCES core.unit(code), balance_basis text, aggregation_rule text, sign_convention text,
 sensitivity text NOT NULL DEFAULT 'CONFIDENTIAL' CHECK(sensitivity IN ('PUBLIC','INTERNAL','CONFIDENTIAL','RESTRICTED')),
 physical_schema text, physical_table text, physical_column text,
 business_approved_by bigint REFERENCES iam.principal(id), business_approved_at timestamptz,
 technical_verified_by bigint REFERENCES iam.principal(id), technical_verified_at timestamptz,
 status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','PENDING','APPROVED','RETIRED')),
 UNIQUE(dataset_id,code,version_no));
CREATE TABLE core.source_field_mapping(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, field_id bigint NOT NULL REFERENCES core.field_definition(id),
 company_id bigint REFERENCES source.company(id), entity_id bigint REFERENCES core.entity(id),
 source_reference text NOT NULL, source_field_path text NOT NULL, transformation_reference text,
 purpose text NOT NULL CHECK(purpose IN ('PRIMARY','SUPPLEMENT','REPLACEMENT','COMPARISON')),
 effective_from date NOT NULL, effective_to date, CHECK(effective_to IS NULL OR effective_to>=effective_from));
CREATE TABLE core.quality_rule(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, dataset_id bigint NOT NULL REFERENCES core.dataset(id),
 code text NOT NULL, version_no integer NOT NULL CHECK(version_no>0), description text NOT NULL,
 validation_reference text NOT NULL, tolerance numeric, severity text NOT NULL CHECK(severity IN ('INFO','WARNING','BLOCKER')),
 business_owner text, UNIQUE(dataset_id,code,version_no));
CREATE TABLE core.lineage_edge(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, from_reference text NOT NULL, to_reference text NOT NULL,
 transformation_reference text, effective_from date NOT NULL, effective_to date,
 CHECK(effective_to IS NULL OR effective_to>=effective_from));
CREATE TABLE core.definition_change(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, object_reference text NOT NULL,
 changed_by bigint NOT NULL REFERENCES iam.principal(id), changed_at timestamptz NOT NULL DEFAULT now(), reason text NOT NULL,
 old_version text, new_version text);
CREATE TABLE ai.route_policy(
 sensitivity text PRIMARY KEY CHECK(sensitivity IN ('PUBLIC','INTERNAL','CONFIDENTIAL','RESTRICTED')),
 route text NOT NULL DEFAULT 'BLOCKED' CHECK(route IN ('BLOCKED','PRIVATE_APPROVED','EXTERNAL_APPROVED')),
 approved_by bigint REFERENCES iam.principal(id), approved_at timestamptz,
 CHECK(route='BLOCKED' OR (approved_by IS NOT NULL AND approved_at IS NOT NULL)));
CREATE TABLE ai.question_event(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, actor_id bigint NOT NULL REFERENCES iam.principal(id),
 occurred_at timestamptz NOT NULL DEFAULT now(), dataset_id bigint REFERENCES core.dataset(id),
 route_decision text NOT NULL DEFAULT 'BLOCKED', retrieval_references jsonb NOT NULL DEFAULT '[]', outcome text NOT NULL);
COMMENT ON SCHEMA ai IS 'Future governance metadata only; no model execution, agent runtime or AI rollout included.';
-- Freeze approved TB data and approved mapping/rule definitions. SQL owner can always bypass controls.
CREATE FUNCTION finance.guard_approved_parent() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF OLD.status='APPROVED' THEN RAISE EXCEPTION 'Approved input/definition is immutable; create a new version'; END IF;
 IF TG_OP='UPDATE' AND NEW.status='APPROVED' THEN
  IF TG_TABLE_NAME='trial_balance' THEN
   IF NOT EXISTS(SELECT 1 FROM source.ingestion_run WHERE id=NEW.run_id AND status='SUCCEEDED')
   THEN RAISE EXCEPTION 'TB source run must succeed'; END IF;
  END IF;
  IF TG_TABLE_NAME='mapping_set' AND EXISTS(SELECT 1 FROM finance.account_mapping a JOIN finance.account_mapping b
   ON a.mapping_set_id=b.mapping_set_id AND a.account_id=b.account_id AND a.id<b.id
   AND daterange(a.effective_from,a.effective_to,'[]') && daterange(b.effective_from,b.effective_to,'[]')
   WHERE a.mapping_set_id=NEW.id) THEN RAISE EXCEPTION 'Overlapping account mappings'; END IF;
 END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER tb_guard BEFORE UPDATE OR DELETE ON finance.trial_balance FOR EACH ROW EXECUTE FUNCTION finance.guard_approved_parent();
CREATE TRIGGER mapping_set_guard BEFORE UPDATE OR DELETE ON finance.mapping_set FOR EACH ROW EXECUTE FUNCTION finance.guard_approved_parent();
CREATE TRIGGER rule_set_guard BEFORE UPDATE OR DELETE ON finance.rule_set FOR EACH ROW EXECUTE FUNCTION finance.guard_approved_parent();
CREATE FUNCTION finance.guard_tb_line() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE k bigint; st text; BEGIN
 IF TG_OP='UPDATE' AND NEW.trial_balance_id<>OLD.trial_balance_id THEN RAISE EXCEPTION 'Cannot move TB line'; END IF;
 IF TG_OP='DELETE' THEN k:=OLD.trial_balance_id; ELSE k:=NEW.trial_balance_id; END IF;
 SELECT status INTO st FROM finance.trial_balance WHERE id=k FOR UPDATE;
 IF st<>'DRAFT' THEN RAISE EXCEPTION 'TB lines require DRAFT parent'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER tb_line_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.trial_balance_line FOR EACH ROW EXECUTE FUNCTION finance.guard_tb_line();
CREATE FUNCTION finance.guard_mapping_member() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE k bigint; st text; BEGIN
 IF TG_OP='UPDATE' AND NEW.mapping_set_id<>OLD.mapping_set_id THEN RAISE EXCEPTION 'Cannot move account mapping'; END IF;
 IF TG_OP='DELETE' THEN k:=OLD.mapping_set_id; ELSE k:=NEW.mapping_set_id; END IF;
 SELECT status INTO st FROM finance.mapping_set WHERE id=k FOR UPDATE;
 IF st<>'DRAFT' THEN RAISE EXCEPTION 'Mappings require DRAFT parent'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER mapping_member_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.account_mapping FOR EACH ROW EXECUTE FUNCTION finance.guard_mapping_member();


CREATE TRIGGER raw_record_immutable BEFORE UPDATE OR DELETE ON source.raw_record FOR EACH ROW EXECUTE FUNCTION audit.deny_mutation();
CREATE TRIGGER file_evidence_immutable BEFORE UPDATE OR DELETE ON source.file FOR EACH ROW EXECUTE FUNCTION audit.deny_mutation();
CREATE TRIGGER file_record_immutable BEFORE UPDATE OR DELETE ON source.file_record FOR EACH ROW EXECUTE FUNCTION audit.deny_mutation();
CREATE TRIGGER bank_snapshot_immutable BEFORE UPDATE OR DELETE ON finance.bank_balance_snapshot FOR EACH ROW EXECUTE FUNCTION audit.deny_mutation();
CREATE TRIGGER fx_rate_immutable BEFORE UPDATE OR DELETE ON finance.fx_rate FOR EACH ROW EXECUTE FUNCTION audit.deny_mutation();
CREATE FUNCTION finance.guard_series() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF EXISTS(SELECT 1 FROM finance.report_version WHERE series_id=OLD.id)
 THEN RAISE EXCEPTION 'Report series identity is immutable once versions exist'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER series_guard BEFORE UPDATE OR DELETE ON finance.report_series FOR EACH ROW EXECUTE FUNCTION finance.guard_series();
CREATE FUNCTION finance.guard_calculation_run() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE v finance.report_version; BEGIN
 IF TG_OP<>'INSERT' AND OLD.status='SUCCEEDED' THEN RAISE EXCEPTION 'Successful calculation is immutable'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF;
 SELECT * INTO STRICT v FROM finance.report_version WHERE id=NEW.report_version_id FOR UPDATE;
 IF v.status<>'DRAFT' OR v.origin<>'SYSTEM_CALCULATED' THEN RAISE EXCEPTION 'Calculation requires draft system-calculated report'; END IF;
 IF NOT EXISTS(SELECT 1 FROM finance.mapping_set WHERE id=NEW.mapping_set_id AND status='APPROVED')
 OR NOT EXISTS(SELECT 1 FROM finance.rule_set WHERE id=NEW.rule_set_id AND status='APPROVED')
 THEN RAISE EXCEPTION 'Calculation definitions must be approved'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER calculation_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.calculation_run FOR EACH ROW EXECUTE FUNCTION finance.guard_calculation_run();
CREATE FUNCTION finance.guard_calculation_input() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE k bigint; st text; BEGIN
 IF TG_OP='UPDATE' AND NEW.calculation_run_id<>OLD.calculation_run_id THEN RAISE EXCEPTION 'Cannot move calculation input'; END IF;
 IF TG_OP='DELETE' THEN k:=OLD.calculation_run_id; ELSE k:=NEW.calculation_run_id; END IF;
 SELECT status INTO st FROM finance.calculation_run WHERE id=k FOR UPDATE;
 IF st<>'RUNNING' THEN RAISE EXCEPTION 'Inputs require RUNNING calculation'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF;
 IF TG_TABLE_NAME='calculation_input' AND NOT EXISTS(SELECT 1 FROM finance.trial_balance WHERE id=NEW.trial_balance_id AND status='APPROVED')
 THEN RAISE EXCEPTION 'Calculation input TB must be approved'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER calculation_input_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.calculation_input FOR EACH ROW EXECUTE FUNCTION finance.guard_calculation_input();
-- Separate FX trigger avoids referencing a field not present on the FX input record.
CREATE FUNCTION finance.guard_calculation_fx() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE k bigint; st text; BEGIN
 IF TG_OP='UPDATE' AND NEW.calculation_run_id<>OLD.calculation_run_id THEN RAISE EXCEPTION 'Cannot move FX input'; END IF;
 IF TG_OP='DELETE' THEN k:=OLD.calculation_run_id; ELSE k:=NEW.calculation_run_id; END IF;
 SELECT status INTO st FROM finance.calculation_run WHERE id=k FOR UPDATE;
 IF st<>'RUNNING' THEN RAISE EXCEPTION 'FX inputs require RUNNING calculation'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER calculation_fx_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.calculation_fx_input FOR EACH ROW EXECUTE FUNCTION finance.guard_calculation_fx();
CREATE TRIGGER cell_lineage_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.cell_lineage FOR EACH ROW EXECUTE FUNCTION finance.guard_adjustment();
-- Successful runs/validation evidence cannot subsequently be rewritten by normal DML.
CREATE FUNCTION source.guard_successful_run() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF OLD.status='SUCCEEDED' THEN RAISE EXCEPTION 'Completed ingestion run is immutable'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER run_guard BEFORE UPDATE OR DELETE ON source.ingestion_run FOR EACH ROW EXECUTE FUNCTION source.guard_successful_run();
COMMIT;
