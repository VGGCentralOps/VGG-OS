-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

CREATE TABLE source.system(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL UNIQUE, name text NOT NULL,
 kind text NOT NULL CHECK(kind IN ('ERP','BANK_API','WORKBOOK','DOCUMENT_STORE','MANUAL','OTHER')));
CREATE TABLE source.instance(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, system_id bigint NOT NULL REFERENCES source.system(id),
 code text NOT NULL UNIQUE, base_url text, credential_secret_reference text,
 auth_method text, network_notes text, active boolean NOT NULL DEFAULT false);
COMMENT ON COLUMN source.instance.credential_secret_reference IS 'Secret-store reference only, never an API key, password, token or connection string.';
CREATE TABLE source.company(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, instance_id bigint NOT NULL REFERENCES source.instance(id),
 external_company_key text NOT NULL, entity_id bigint NOT NULL REFERENCES core.entity(id),
 UNIQUE(instance_id,external_company_key), UNIQUE(id,entity_id));
CREATE TABLE source.file(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, system_id bigint REFERENCES source.system(id),
 file_name text NOT NULL, storage_reference text NOT NULL, sha256 text NOT NULL CHECK(sha256 ~ '^[a-f0-9]{64}$'),
 uploaded_at timestamptz NOT NULL DEFAULT now(), uploaded_by bigint REFERENCES iam.principal(id),
 entity_id bigint REFERENCES core.entity(id), sensitivity text NOT NULL DEFAULT 'CONFIDENTIAL'
 CHECK(sensitivity IN ('PUBLIC','INTERNAL','CONFIDENTIAL','RESTRICTED')), source_version text);
CREATE TABLE source.sync_stream(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, company_id bigint NOT NULL REFERENCES source.company(id),
 endpoint_code text NOT NULL, query_scope jsonb NOT NULL DEFAULT '{}', scope_hash text NOT NULL,
 committed_checkpoint jsonb NOT NULL DEFAULT '{}', updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(company_id,endpoint_code,scope_hash));
CREATE TABLE source.ingestion_run(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, stream_id bigint REFERENCES source.sync_stream(id),
 file_id bigint REFERENCES source.file(id), dataset_id bigint REFERENCES core.dataset(id),
 idempotency_key text NOT NULL UNIQUE, status text NOT NULL DEFAULT 'CREATED'
 CHECK(status IN ('CREATED','RUNNING','STAGED','VALIDATED','SUCCEEDED','FAILED','CANCELLED')),
 started_at timestamptz NOT NULL DEFAULT now(), finished_at timestamptz,
 requested_by bigint REFERENCES iam.principal(id), checkpoint_before jsonb, checkpoint_after jsonb,
 rows_read bigint NOT NULL DEFAULT 0 CHECK(rows_read>=0), rows_accepted bigint NOT NULL DEFAULT 0 CHECK(rows_accepted>=0),
 rows_rejected bigint NOT NULL DEFAULT 0 CHECK(rows_rejected>=0), error_summary text,
 CHECK((stream_id IS NOT NULL)::integer+(file_id IS NOT NULL)::integer=1),
 CHECK(status<>'SUCCEEDED' OR (finished_at IS NOT NULL AND rows_read=rows_accepted+rows_rejected)),
 UNIQUE(id,stream_id));
CREATE UNIQUE INDEX one_running_stream ON source.ingestion_run(stream_id) WHERE status='RUNNING';
CREATE TABLE source.raw_record(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, run_id bigint NOT NULL REFERENCES source.ingestion_run(id),
 record_key text NOT NULL, source_version text NOT NULL, source_modified_at timestamptz,
 payload jsonb NOT NULL, payload_sha256 text NOT NULL CHECK(payload_sha256 ~ '^[a-f0-9]{64}$'),
 is_deleted boolean NOT NULL DEFAULT false, retrieved_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(run_id,record_key,source_version), UNIQUE(id,run_id));
CREATE INDEX raw_record_key ON source.raw_record(record_key);
CREATE TABLE source.validation_result(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, run_id bigint NOT NULL REFERENCES source.ingestion_run(id),
 raw_record_id bigint REFERENCES source.raw_record(id), rule_code text NOT NULL,
 severity text NOT NULL CHECK(severity IN ('INFO','WARNING','BLOCKER')),
 passed boolean NOT NULL, expected_value text, actual_value text, tolerance numeric,
 message text NOT NULL, checked_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(raw_record_id,run_id) REFERENCES source.raw_record(id,run_id));
CREATE TABLE source.file_record(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, file_id bigint NOT NULL REFERENCES source.file(id),
 sheet_name text NOT NULL, source_locator text NOT NULL, raw_text text,
 UNIQUE(file_id,sheet_name,source_locator));
-- A stream checkpoint advances ONLY on successful validation, in the same transaction as completion.
-- Caller commits normalised upserts in this transaction before invoking this function.
CREATE FUNCTION source.complete_run(p_run bigint, p_actor bigint) RETURNS void LANGUAGE plpgsql AS $$
DECLARE r source.ingestion_run; BEGIN
 SELECT * INTO STRICT r FROM source.ingestion_run WHERE id=p_run FOR UPDATE;
 IF r.status<>'VALIDATED' THEN RAISE EXCEPTION 'Run must be VALIDATED'; END IF;
 IF EXISTS(SELECT 1 FROM source.validation_result WHERE run_id=p_run AND severity='BLOCKER' AND NOT passed)
 THEN RAISE EXCEPTION 'Blocking validation failed'; END IF;
 IF r.stream_id IS NOT NULL THEN
  PERFORM 1 FROM source.sync_stream WHERE id=r.stream_id FOR UPDATE;
  IF (SELECT committed_checkpoint FROM source.sync_stream WHERE id=r.stream_id) IS DISTINCT FROM r.checkpoint_before
  THEN RAISE EXCEPTION 'Stale checkpoint'; END IF;
  IF r.checkpoint_after IS NULL THEN RAISE EXCEPTION 'Missing next checkpoint'; END IF;
  UPDATE source.sync_stream SET committed_checkpoint=r.checkpoint_after,updated_at=now() WHERE id=r.stream_id;
 END IF;
 UPDATE source.ingestion_run SET status='SUCCEEDED',finished_at=clock_timestamp() WHERE id=p_run;
 INSERT INTO audit.event(actor_id,action,object_type,object_id) VALUES(p_actor,'INGESTION_COMPLETE','INGESTION_RUN',p_run::text);
END $$;

COMMIT;
