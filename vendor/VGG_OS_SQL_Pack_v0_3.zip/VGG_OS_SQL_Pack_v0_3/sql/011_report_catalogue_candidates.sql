-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

-- Confirm 13-report scope vs 14 tabs; two weekly cash sheets may be parts of one report.
-- This seeds catalogue candidates only, NOT report definitions, historical values or financial rules.
INSERT INTO finance.report(code,name,source_sheet,dataset_id,notes)
SELECT x.code,x.name,x.name,d.id,'Workbook candidate: Finance to confirm scope, owner, cadence, layout and history.'
FROM (VALUES ('COMPLIANCE','Compliance Report'),
('WEEKLY_CASH_1','Weekly Cash Position 1'),
('WEEKLY_CASH_2','Weekly Cash Position 2'),
('MANCO_FINANCIALS','Manco Financials'),
('VGG_SOFP','Vgg SOFP'),
('INCUBATED_INVESTMENTS','Investment in incubated Com'),
('INTERCOMPANY_OWINGS','Intercompany owings'),
('GROUP_MANAGEMENT','Group Management Acc'),
('SERVICE_COMPANIES','Service Company Report'),
('ACTUAL_BUDGET','Actual Vs Budget Report'),
('GROUP_MONTH_ON_MONTH','Group Month on Month'),
('SUBMISSION_HEAT_MAP','Monthly Heat Map Report'),
('PARTNERS_EXPENSES','Partners Expense Report'),
('DEBT_OBLIGATIONS','Debt Obligation Report')) AS x(code,name)
CROSS JOIN core.dataset d WHERE d.code='FINANCE_GROUP_REPORTS';

COMMIT;
