-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

CREATE TABLE finance.report(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL UNIQUE, name text NOT NULL,
 dataset_id bigint NOT NULL REFERENCES core.dataset(id), owner_name text,
 cadence text CHECK(cadence IN ('DAILY','WEEKLY','MONTHLY','QUARTERLY','ANNUAL','AD_HOC')),
 catalogue_status text NOT NULL DEFAULT 'PENDING' CHECK(catalogue_status IN ('PENDING','CONFIRMED','RETIRED')),
 source_sheet text, notes text);
CREATE TABLE finance.layout(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, report_id bigint NOT NULL REFERENCES finance.report(id),
 version_no integer NOT NULL CHECK(version_no>0), status text NOT NULL DEFAULT 'DRAFT'
 CHECK(status IN ('DRAFT','APPROVED')), description text,
 approved_by bigint REFERENCES iam.principal(id), approved_at timestamptz,
 UNIQUE(report_id,version_no), UNIQUE(id,report_id),
 CHECK(status<>'APPROVED' OR (approved_by IS NOT NULL AND approved_at IS NOT NULL)));
CREATE TABLE finance.layout_row(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, layout_id bigint NOT NULL REFERENCES finance.layout(id),
 code text NOT NULL, label text NOT NULL, display_order integer NOT NULL CHECK(display_order>=0),
 row_type text NOT NULL CHECK(row_type IN ('HEADING','VALUE','SUBTOTAL','TOTAL','NOTE')),
 parent_row_id bigint, entity_id bigint REFERENCES core.entity(id),
 dimension_labels jsonb NOT NULL DEFAULT '{}',
 UNIQUE(layout_id,code), UNIQUE(id,layout_id),
 FOREIGN KEY(parent_row_id,layout_id) REFERENCES finance.layout_row(id,layout_id),
 CHECK(parent_row_id IS NULL OR parent_row_id<>id));
CREATE TABLE finance.layout_column(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, layout_id bigint NOT NULL REFERENCES finance.layout(id),
 code text NOT NULL, label text NOT NULL, display_order integer NOT NULL CHECK(display_order>=0),
 value_type text NOT NULL CHECK(value_type IN ('NUMBER','TEXT','DATE','BOOLEAN')),
 unit_code text NOT NULL REFERENCES core.unit(code), currency_code text REFERENCES core.currency(code),
 display_scale numeric NOT NULL DEFAULT 1 CHECK(display_scale>0), decimals smallint CHECK(decimals BETWEEN 0 AND 10),
 period_id bigint REFERENCES core.period(id), scenario_code text REFERENCES core.scenario(code),
 entity_id bigint REFERENCES core.entity(id), comparison_type text,
 UNIQUE(layout_id,code), UNIQUE(id,layout_id));
CREATE TABLE finance.report_series(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, report_id bigint NOT NULL REFERENCES finance.report(id),
 period_id bigint NOT NULL REFERENCES core.period(id), scope_entity_id bigint NOT NULL REFERENCES core.entity(id),
 variant_code text NOT NULL DEFAULT 'STANDARD', UNIQUE(report_id,period_id,scope_entity_id,variant_code),
 UNIQUE(id,report_id));
CREATE TABLE finance.report_version(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, series_id bigint NOT NULL, report_id bigint NOT NULL,
 layout_id bigint NOT NULL, version_no integer NOT NULL CHECK(version_no>0),
 origin text NOT NULL CHECK(origin IN ('FINANCE_PREPARED','SYSTEM_CALCULATED')),
 status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','SUBMITTED','APPROVED','REJECTED','SUPERSEDED')),
 source_file_id bigint REFERENCES source.file(id), ingestion_run_id bigint REFERENCES source.ingestion_run(id),
 created_by bigint NOT NULL REFERENCES iam.principal(id), created_at timestamptz NOT NULL DEFAULT now(),
 approved_by bigint REFERENCES iam.principal(id), approved_at timestamptz, approval_note text,
 FOREIGN KEY(series_id,report_id) REFERENCES finance.report_series(id,report_id),
 FOREIGN KEY(layout_id,report_id) REFERENCES finance.layout(id,report_id),
 UNIQUE(series_id,version_no), UNIQUE(id,series_id), UNIQUE(id,layout_id),
 CHECK(origin<>'FINANCE_PREPARED' OR source_file_id IS NOT NULL),
 CHECK(status NOT IN ('APPROVED','SUPERSEDED') OR (approved_by IS NOT NULL AND approved_at IS NOT NULL)));
CREATE TABLE finance.report_cell(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, version_id bigint NOT NULL, layout_id bigint NOT NULL,
 row_id bigint NOT NULL, column_id bigint NOT NULL,
 value_status text NOT NULL CHECK(value_status IN ('PRESENT','MISSING','NOT_APPLICABLE','SUPPRESSED')),
 numeric_value numeric(28,8), text_value text, date_value date, boolean_value boolean,
 unit_code text REFERENCES core.unit(code), currency_code text REFERENCES core.currency(code),
 entity_id bigint REFERENCES core.entity(id), organisation_unit_id bigint,
 source_file_record_id bigint REFERENCES source.file_record(id), source_raw_record_id bigint REFERENCES source.raw_record(id),
 FOREIGN KEY(version_id,layout_id) REFERENCES finance.report_version(id,layout_id),
 FOREIGN KEY(row_id,layout_id) REFERENCES finance.layout_row(id,layout_id),
 FOREIGN KEY(column_id,layout_id) REFERENCES finance.layout_column(id,layout_id),
 FOREIGN KEY(organisation_unit_id,entity_id) REFERENCES core.organisation_unit(id,entity_id),
 CHECK(organisation_unit_id IS NULL OR entity_id IS NOT NULL),
 UNIQUE(version_id,row_id,column_id),
 CHECK((value_status='PRESENT' AND num_nonnulls(numeric_value,text_value,date_value,boolean_value)=1)
 OR (value_status<>'PRESENT' AND num_nonnulls(numeric_value,text_value,date_value,boolean_value)=0)));
COMMENT ON COLUMN finance.report_cell.numeric_value IS 'Canonical amount/number. Display is numeric_value / column.display_scale. Percent values are percentage points with scale 1; never infer scaling from text.';
CREATE TABLE finance.publication(
 series_id bigint PRIMARY KEY REFERENCES finance.report_series(id), version_id bigint NOT NULL UNIQUE,
 published_by bigint NOT NULL REFERENCES iam.principal(id), published_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(version_id,series_id) REFERENCES finance.report_version(id,series_id));
ALTER TABLE audit.export_event ADD FOREIGN KEY(report_version_id) REFERENCES finance.report_version(id);
CREATE TABLE finance.report_coverage(
 report_id bigint NOT NULL REFERENCES finance.report(id), period_id bigint NOT NULL REFERENCES core.period(id),
 scope_entity_id bigint NOT NULL REFERENCES core.entity(id), variant_code text NOT NULL DEFAULT 'STANDARD',
 status text NOT NULL CHECK(status IN ('EXPECTED','RECEIVED','LOADED','ACCEPTED','UNAVAILABLE')),
 source_file_id bigint REFERENCES source.file(id), note text,
 PRIMARY KEY(report_id,period_id,scope_entity_id,variant_code));
CREATE TABLE finance.cell_adjustment(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, cell_id bigint NOT NULL REFERENCES finance.report_cell(id),
 amount numeric(28,8) NOT NULL, currency_code text NOT NULL REFERENCES core.currency(code),
 kind text NOT NULL CHECK(kind IN ('CONSOLIDATION','INTERCOMPANY','FX','MANAGEMENT','OTHER')),
 reason text NOT NULL, approved_by bigint NOT NULL REFERENCES iam.principal(id), approved_at timestamptz NOT NULL,
 included_in_cell boolean NOT NULL,
 source_file_id bigint REFERENCES source.file(id));
COMMENT ON TABLE finance.cell_adjustment IS 'Explanation/evidence. Serving views NEVER add these amounts automatically; report_cell holds the accepted final figure, avoiding double counting.';
CREATE INDEX report_version_series ON finance.report_version(series_id);
CREATE INDEX report_cell_entity ON finance.report_cell(entity_id);

COMMIT;
