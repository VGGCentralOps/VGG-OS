-- VGG OS v0.3.0 FRESH INSTALL ONLY. PostgreSQL 15+.
-- Empty database required. No credentials, drops or live data.
-- Equivalent to install.sql; run ONE installation route, not both.
-- SQL client must stop on the first error. Scripts commit separately.

-- FILE: 001_core.sql
-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

CREATE SCHEMA core; CREATE SCHEMA iam; CREATE SCHEMA source; CREATE SCHEMA finance;
CREATE SCHEMA audit; CREATE SCHEMA ai;
CREATE SCHEMA hr; CREATE SCHEMA ops; CREATE SCHEMA risk; CREATE SCHEMA legal; CREATE SCHEMA product;
CREATE TABLE core.schema_version(version text PRIMARY KEY, installed_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE core.module(code text PRIMARY KEY, name text NOT NULL, active boolean NOT NULL DEFAULT true);
CREATE TABLE core.currency(code text PRIMARY KEY CHECK(code ~ '^[A-Z]{3}$'), name text NOT NULL, decimals smallint NOT NULL DEFAULT 2 CHECK(decimals BETWEEN 0 AND 6));
CREATE TABLE core.entity(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL UNIQUE, name text NOT NULL,
 entity_type text NOT NULL CHECK(entity_type IN ('GROUP','LEGAL_ENTITY','INCUBATED','OTHER')),
 parent_id bigint REFERENCES core.entity(id), functional_currency text REFERENCES core.currency(code),
 country_code text CHECK(country_code ~ '^[A-Z]{2}$'), active boolean NOT NULL DEFAULT true,
 CHECK(parent_id IS NULL OR parent_id<>id));
CREATE TABLE core.entity_alias(alias text PRIMARY KEY, entity_id bigint NOT NULL REFERENCES core.entity(id));
CREATE TABLE core.organisation_unit(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, entity_id bigint NOT NULL REFERENCES core.entity(id),
 code text NOT NULL, name text NOT NULL, UNIQUE(entity_id,code), UNIQUE(id,entity_id));
CREATE TABLE core.period(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL UNIQUE, name text NOT NULL,
 kind text NOT NULL CHECK(kind IN ('DAY','WEEK','MONTH','QUARTER','YEAR','YTD','CUSTOM')),
 start_date date NOT NULL, end_date date NOT NULL, fiscal_year integer NOT NULL,
 CHECK(end_date>=start_date));
CREATE TABLE core.dataset(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL UNIQUE, name text NOT NULL,
 module_code text NOT NULL REFERENCES core.module(code), business_owner text,
 sensitivity text NOT NULL DEFAULT 'CONFIDENTIAL' CHECK(sensitivity IN ('PUBLIC','INTERNAL','CONFIDENTIAL','RESTRICTED')),
 definition_status text NOT NULL DEFAULT 'DRAFT' CHECK(definition_status IN ('DRAFT','PENDING','APPROVED','RETIRED')),
 grain_description text, active boolean NOT NULL DEFAULT true);
CREATE TABLE core.unit(code text PRIMARY KEY, name text NOT NULL);
CREATE TABLE core.scenario(code text PRIMARY KEY, name text NOT NULL);
COMMENT ON SCHEMA hr IS 'Reserved only; no confirmed HR input model is assumed.';
COMMENT ON SCHEMA ops IS 'Reserved for future domain migrations.';
COMMENT ON SCHEMA risk IS 'Reserved for future domain migrations.';
COMMENT ON SCHEMA legal IS 'Reserved for future domain migrations.';
COMMENT ON SCHEMA product IS 'Reserved for future domain migrations.';

COMMIT;


-- FILE: 002_identity_audit.sql
-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

-- No passwords, local registration workflow or parallel directory administration.
CREATE TABLE iam.identity_provider(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL UNIQUE,
 issuer text NOT NULL, tenant_reference text NOT NULL DEFAULT '', configuration_status text NOT NULL DEFAULT 'PENDING'
 CHECK(configuration_status IN ('PENDING','CONFIRMED','DISABLED')), UNIQUE(issuer,tenant_reference));
CREATE TABLE iam.principal(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, provider_id bigint NOT NULL REFERENCES iam.identity_provider(id),
 external_subject text NOT NULL, display_name text, email text,
 principal_type text NOT NULL CHECK(principal_type IN ('USER','SERVICE')),
 active boolean NOT NULL DEFAULT true, UNIQUE(provider_id,external_subject));
CREATE TABLE iam.entitlement_mapping(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, provider_id bigint NOT NULL REFERENCES iam.identity_provider(id),
 external_entitlement text NOT NULL, action text NOT NULL CHECK(action IN ('VIEW','EXPORT','UPLOAD','APPROVE','ADMIN')),
 module_code text NOT NULL REFERENCES core.module(code), entity_id bigint REFERENCES core.entity(id),
 dataset_id bigint REFERENCES core.dataset(id), all_entities boolean NOT NULL DEFAULT false,
 effective_from timestamptz NOT NULL DEFAULT now(), effective_to timestamptz,
 CHECK((all_entities AND entity_id IS NULL) OR (NOT all_entities AND entity_id IS NOT NULL)),
 CHECK(effective_to IS NULL OR effective_to>effective_from));
COMMENT ON TABLE iam.entitlement_mapping IS 'Optional mapping from externally verified groups/app roles; backend evaluates combined scope. No active mappings seeded.';
CREATE TABLE audit.event(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, occurred_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 actor_id bigint REFERENCES iam.principal(id), db_actor text NOT NULL DEFAULT session_user,
 action text NOT NULL, object_type text NOT NULL, object_id text,
 outcome text NOT NULL DEFAULT 'SUCCESS' CHECK(outcome IN ('SUCCESS','FAILED','DENIED')),
 correlation_id text, details jsonb NOT NULL DEFAULT '{}');
CREATE TABLE audit.export_event(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, occurred_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 actor_id bigint NOT NULL REFERENCES iam.principal(id), report_version_id bigint,
 format text NOT NULL CHECK(format IN ('CSV','XLSX','PDF')), filters jsonb NOT NULL,
 row_count bigint CHECK(row_count>=0), outcome text NOT NULL CHECK(outcome IN ('SUCCESS','FAILED','DENIED')));
CREATE FUNCTION audit.deny_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'Evidence/history is append-only'; END $$;
CREATE TRIGGER immutable_event BEFORE UPDATE OR DELETE ON audit.event FOR EACH ROW EXECUTE FUNCTION audit.deny_mutation();
CREATE TRIGGER immutable_export BEFORE UPDATE OR DELETE ON audit.export_event FOR EACH ROW EXECUTE FUNCTION audit.deny_mutation();

COMMIT;


-- FILE: 003_source_ingestion.sql
-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

CREATE TABLE source.system(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL UNIQUE, name text NOT NULL,
 kind text NOT NULL CHECK(kind IN ('ERP','BANK_API','WORKBOOK','DOCUMENT_STORE','MANUAL','OTHER')));
CREATE TABLE source.instance(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, system_id bigint NOT NULL REFERENCES source.system(id),
 code text NOT NULL UNIQUE, base_url text, credential_secret_reference text,
 auth_method text, network_notes text, active boolean NOT NULL DEFAULT false);
COMMENT ON COLUMN source.instance.credential_secret_reference IS 'Secret-store reference only, never an API key, password, token or connection string.';
CREATE TABLE source.company(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, instance_id bigint NOT NULL REFERENCES source.instance(id),
 external_company_key text NOT NULL, entity_id bigint NOT NULL REFERENCES core.entity(id),
 UNIQUE(instance_id,external_company_key), UNIQUE(id,entity_id));
CREATE TABLE source.file(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, system_id bigint REFERENCES source.system(id),
 file_name text NOT NULL, storage_reference text NOT NULL, sha256 text NOT NULL CHECK(sha256 ~ '^[a-f0-9]{64}$'),
 uploaded_at timestamptz NOT NULL DEFAULT now(), uploaded_by bigint REFERENCES iam.principal(id),
 entity_id bigint REFERENCES core.entity(id), sensitivity text NOT NULL DEFAULT 'CONFIDENTIAL'
 CHECK(sensitivity IN ('PUBLIC','INTERNAL','CONFIDENTIAL','RESTRICTED')), source_version text);
CREATE TABLE source.sync_stream(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, company_id bigint NOT NULL REFERENCES source.company(id),
 endpoint_code text NOT NULL, query_scope jsonb NOT NULL DEFAULT '{}', scope_hash text NOT NULL,
 committed_checkpoint jsonb NOT NULL DEFAULT '{}', updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(company_id,endpoint_code,scope_hash));
CREATE TABLE source.ingestion_run(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, stream_id bigint REFERENCES source.sync_stream(id),
 file_id bigint REFERENCES source.file(id), dataset_id bigint REFERENCES core.dataset(id),
 idempotency_key text NOT NULL UNIQUE, status text NOT NULL DEFAULT 'CREATED'
 CHECK(status IN ('CREATED','RUNNING','STAGED','VALIDATED','SUCCEEDED','FAILED','CANCELLED')),
 started_at timestamptz NOT NULL DEFAULT now(), finished_at timestamptz,
 requested_by bigint REFERENCES iam.principal(id), checkpoint_before jsonb, checkpoint_after jsonb,
 rows_read bigint NOT NULL DEFAULT 0 CHECK(rows_read>=0), rows_accepted bigint NOT NULL DEFAULT 0 CHECK(rows_accepted>=0),
 rows_rejected bigint NOT NULL DEFAULT 0 CHECK(rows_rejected>=0), error_summary text,
 CHECK((stream_id IS NOT NULL)::integer+(file_id IS NOT NULL)::integer=1),
 CHECK(status<>'SUCCEEDED' OR (finished_at IS NOT NULL AND rows_read=rows_accepted+rows_rejected)),
 UNIQUE(id,stream_id));
CREATE UNIQUE INDEX one_running_stream ON source.ingestion_run(stream_id) WHERE status='RUNNING';
CREATE TABLE source.raw_record(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, run_id bigint NOT NULL REFERENCES source.ingestion_run(id),
 record_key text NOT NULL, source_version text NOT NULL, source_modified_at timestamptz,
 payload jsonb NOT NULL, payload_sha256 text NOT NULL CHECK(payload_sha256 ~ '^[a-f0-9]{64}$'),
 is_deleted boolean NOT NULL DEFAULT false, retrieved_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(run_id,record_key,source_version), UNIQUE(id,run_id));
CREATE INDEX raw_record_key ON source.raw_record(record_key);
CREATE TABLE source.validation_result(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, run_id bigint NOT NULL REFERENCES source.ingestion_run(id),
 raw_record_id bigint REFERENCES source.raw_record(id), rule_code text NOT NULL,
 severity text NOT NULL CHECK(severity IN ('INFO','WARNING','BLOCKER')),
 passed boolean NOT NULL, expected_value text, actual_value text, tolerance numeric,
 message text NOT NULL, checked_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(raw_record_id,run_id) REFERENCES source.raw_record(id,run_id));
CREATE TABLE source.file_record(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, file_id bigint NOT NULL REFERENCES source.file(id),
 sheet_name text NOT NULL, source_locator text NOT NULL, raw_text text,
 UNIQUE(file_id,sheet_name,source_locator));
-- A stream checkpoint advances ONLY on successful validation, in the same transaction as completion.
-- Caller commits normalised upserts in this transaction before invoking this function.
CREATE FUNCTION source.complete_run(p_run bigint, p_actor bigint) RETURNS void LANGUAGE plpgsql AS $$
DECLARE r source.ingestion_run; BEGIN
 SELECT * INTO STRICT r FROM source.ingestion_run WHERE id=p_run FOR UPDATE;
 IF r.status<>'VALIDATED' THEN RAISE EXCEPTION 'Run must be VALIDATED'; END IF;
 IF EXISTS(SELECT 1 FROM source.validation_result WHERE run_id=p_run AND severity='BLOCKER' AND NOT passed)
 THEN RAISE EXCEPTION 'Blocking validation failed'; END IF;
 IF r.stream_id IS NOT NULL THEN
  PERFORM 1 FROM source.sync_stream WHERE id=r.stream_id FOR UPDATE;
  IF (SELECT committed_checkpoint FROM source.sync_stream WHERE id=r.stream_id) IS DISTINCT FROM r.checkpoint_before
  THEN RAISE EXCEPTION 'Stale checkpoint'; END IF;
  IF r.checkpoint_after IS NULL THEN RAISE EXCEPTION 'Missing next checkpoint'; END IF;
  UPDATE source.sync_stream SET committed_checkpoint=r.checkpoint_after,updated_at=now() WHERE id=r.stream_id;
 END IF;
 UPDATE source.ingestion_run SET status='SUCCEEDED',finished_at=clock_timestamp() WHERE id=p_run;
 INSERT INTO audit.event(actor_id,action,object_type,object_id) VALUES(p_actor,'INGESTION_COMPLETE','INGESTION_RUN',p_run::text);
END $$;

COMMIT;


-- FILE: 004_reporting.sql
-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

CREATE TABLE finance.report(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL UNIQUE, name text NOT NULL,
 dataset_id bigint NOT NULL REFERENCES core.dataset(id), owner_name text,
 cadence text CHECK(cadence IN ('DAILY','WEEKLY','MONTHLY','QUARTERLY','ANNUAL','AD_HOC')),
 catalogue_status text NOT NULL DEFAULT 'PENDING' CHECK(catalogue_status IN ('PENDING','CONFIRMED','RETIRED')),
 source_sheet text, notes text);
CREATE TABLE finance.layout(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, report_id bigint NOT NULL REFERENCES finance.report(id),
 version_no integer NOT NULL CHECK(version_no>0), status text NOT NULL DEFAULT 'DRAFT'
 CHECK(status IN ('DRAFT','APPROVED')), description text,
 approved_by bigint REFERENCES iam.principal(id), approved_at timestamptz,
 UNIQUE(report_id,version_no), UNIQUE(id,report_id),
 CHECK(status<>'APPROVED' OR (approved_by IS NOT NULL AND approved_at IS NOT NULL)));
CREATE TABLE finance.layout_row(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, layout_id bigint NOT NULL REFERENCES finance.layout(id),
 code text NOT NULL, label text NOT NULL, display_order integer NOT NULL CHECK(display_order>=0),
 row_type text NOT NULL CHECK(row_type IN ('HEADING','VALUE','SUBTOTAL','TOTAL','NOTE')),
 parent_row_id bigint, entity_id bigint REFERENCES core.entity(id),
 dimension_labels jsonb NOT NULL DEFAULT '{}',
 UNIQUE(layout_id,code), UNIQUE(id,layout_id),
 FOREIGN KEY(parent_row_id,layout_id) REFERENCES finance.layout_row(id,layout_id),
 CHECK(parent_row_id IS NULL OR parent_row_id<>id));
CREATE TABLE finance.layout_column(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, layout_id bigint NOT NULL REFERENCES finance.layout(id),
 code text NOT NULL, label text NOT NULL, display_order integer NOT NULL CHECK(display_order>=0),
 value_type text NOT NULL CHECK(value_type IN ('NUMBER','TEXT','DATE','BOOLEAN')),
 unit_code text NOT NULL REFERENCES core.unit(code), currency_code text REFERENCES core.currency(code),
 display_scale numeric NOT NULL DEFAULT 1 CHECK(display_scale>0), decimals smallint CHECK(decimals BETWEEN 0 AND 10),
 period_id bigint REFERENCES core.period(id), scenario_code text REFERENCES core.scenario(code),
 entity_id bigint REFERENCES core.entity(id), comparison_type text,
 UNIQUE(layout_id,code), UNIQUE(id,layout_id));
CREATE TABLE finance.report_series(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, report_id bigint NOT NULL REFERENCES finance.report(id),
 period_id bigint NOT NULL REFERENCES core.period(id), scope_entity_id bigint NOT NULL REFERENCES core.entity(id),
 variant_code text NOT NULL DEFAULT 'STANDARD', UNIQUE(report_id,period_id,scope_entity_id,variant_code),
 UNIQUE(id,report_id));
CREATE TABLE finance.report_version(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, series_id bigint NOT NULL, report_id bigint NOT NULL,
 layout_id bigint NOT NULL, version_no integer NOT NULL CHECK(version_no>0),
 origin text NOT NULL CHECK(origin IN ('FINANCE_PREPARED','SYSTEM_CALCULATED')),
 status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','SUBMITTED','APPROVED','REJECTED','SUPERSEDED')),
 source_file_id bigint REFERENCES source.file(id), ingestion_run_id bigint REFERENCES source.ingestion_run(id),
 created_by bigint NOT NULL REFERENCES iam.principal(id), created_at timestamptz NOT NULL DEFAULT now(),
 approved_by bigint REFERENCES iam.principal(id), approved_at timestamptz, approval_note text,
 FOREIGN KEY(series_id,report_id) REFERENCES finance.report_series(id,report_id),
 FOREIGN KEY(layout_id,report_id) REFERENCES finance.layout(id,report_id),
 UNIQUE(series_id,version_no), UNIQUE(id,series_id), UNIQUE(id,layout_id),
 CHECK(origin<>'FINANCE_PREPARED' OR source_file_id IS NOT NULL),
 CHECK(status NOT IN ('APPROVED','SUPERSEDED') OR (approved_by IS NOT NULL AND approved_at IS NOT NULL)));
CREATE TABLE finance.report_cell(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, version_id bigint NOT NULL, layout_id bigint NOT NULL,
 row_id bigint NOT NULL, column_id bigint NOT NULL,
 value_status text NOT NULL CHECK(value_status IN ('PRESENT','MISSING','NOT_APPLICABLE','SUPPRESSED')),
 numeric_value numeric(28,8), text_value text, date_value date, boolean_value boolean,
 unit_code text REFERENCES core.unit(code), currency_code text REFERENCES core.currency(code),
 entity_id bigint REFERENCES core.entity(id), organisation_unit_id bigint,
 source_file_record_id bigint REFERENCES source.file_record(id), source_raw_record_id bigint REFERENCES source.raw_record(id),
 FOREIGN KEY(version_id,layout_id) REFERENCES finance.report_version(id,layout_id),
 FOREIGN KEY(row_id,layout_id) REFERENCES finance.layout_row(id,layout_id),
 FOREIGN KEY(column_id,layout_id) REFERENCES finance.layout_column(id,layout_id),
 FOREIGN KEY(organisation_unit_id,entity_id) REFERENCES core.organisation_unit(id,entity_id),
 CHECK(organisation_unit_id IS NULL OR entity_id IS NOT NULL),
 UNIQUE(version_id,row_id,column_id),
 CHECK((value_status='PRESENT' AND num_nonnulls(numeric_value,text_value,date_value,boolean_value)=1)
 OR (value_status<>'PRESENT' AND num_nonnulls(numeric_value,text_value,date_value,boolean_value)=0)));
COMMENT ON COLUMN finance.report_cell.numeric_value IS 'Canonical amount/number. Display is numeric_value / column.display_scale. Percent values are percentage points with scale 1; never infer scaling from text.';
CREATE TABLE finance.publication(
 series_id bigint PRIMARY KEY REFERENCES finance.report_series(id), version_id bigint NOT NULL UNIQUE,
 published_by bigint NOT NULL REFERENCES iam.principal(id), published_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(version_id,series_id) REFERENCES finance.report_version(id,series_id));
ALTER TABLE audit.export_event ADD FOREIGN KEY(report_version_id) REFERENCES finance.report_version(id);
CREATE TABLE finance.report_coverage(
 report_id bigint NOT NULL REFERENCES finance.report(id), period_id bigint NOT NULL REFERENCES core.period(id),
 scope_entity_id bigint NOT NULL REFERENCES core.entity(id), variant_code text NOT NULL DEFAULT 'STANDARD',
 status text NOT NULL CHECK(status IN ('EXPECTED','RECEIVED','LOADED','ACCEPTED','UNAVAILABLE')),
 source_file_id bigint REFERENCES source.file(id), note text,
 PRIMARY KEY(report_id,period_id,scope_entity_id,variant_code));
CREATE TABLE finance.cell_adjustment(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, cell_id bigint NOT NULL REFERENCES finance.report_cell(id),
 amount numeric(28,8) NOT NULL, currency_code text NOT NULL REFERENCES core.currency(code),
 kind text NOT NULL CHECK(kind IN ('CONSOLIDATION','INTERCOMPANY','FX','MANAGEMENT','OTHER')),
 reason text NOT NULL, approved_by bigint NOT NULL REFERENCES iam.principal(id), approved_at timestamptz NOT NULL,
 included_in_cell boolean NOT NULL,
 source_file_id bigint REFERENCES source.file(id));
COMMENT ON TABLE finance.cell_adjustment IS 'Explanation/evidence. Serving views NEVER add these amounts automatically; report_cell holds the accepted final figure, avoiding double counting.';
CREATE INDEX report_version_series ON finance.report_version(series_id);
CREATE INDEX report_cell_entity ON finance.report_cell(entity_id);

COMMIT;


-- FILE: 005_reporting_controls.sql
-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

CREATE FUNCTION finance.guard_layout() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF OLD.status='APPROVED' THEN RAISE EXCEPTION 'Approved layout is immutable; create a new version'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER layout_guard BEFORE UPDATE OR DELETE ON finance.layout FOR EACH ROW EXECUTE FUNCTION finance.guard_layout();
CREATE FUNCTION finance.guard_layout_member() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE k bigint; st text; BEGIN
 IF TG_OP='UPDATE' AND NEW.layout_id<>OLD.layout_id THEN RAISE EXCEPTION 'Cannot move layout member'; END IF;
 IF TG_OP='DELETE' THEN k:=OLD.layout_id; ELSE k:=NEW.layout_id; END IF;
 SELECT status INTO st FROM finance.layout WHERE id=k FOR UPDATE;
 IF st='APPROVED' THEN RAISE EXCEPTION 'Approved layout members are immutable'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER row_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.layout_row FOR EACH ROW EXECUTE FUNCTION finance.guard_layout_member();
CREATE TRIGGER column_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.layout_column FOR EACH ROW EXECUTE FUNCTION finance.guard_layout_member();
CREATE FUNCTION finance.guard_version() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='INSERT' THEN
  IF NEW.status<>'DRAFT' THEN RAISE EXCEPTION 'New version must be DRAFT'; END IF;
  RETURN NEW;
 END IF;
 IF OLD.status IN ('APPROVED','SUPERSEDED') THEN
  IF TG_OP='DELETE' THEN RAISE EXCEPTION 'Approved history cannot be deleted'; END IF;
  IF NOT(OLD.status='APPROVED' AND NEW.status='SUPERSEDED' AND
   (to_jsonb(NEW)-'status')=(to_jsonb(OLD)-'status')) THEN RAISE EXCEPTION 'Approved history is immutable'; END IF;
 END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF;
 IF NEW.series_id<>OLD.series_id OR NEW.report_id<>OLD.report_id OR NEW.layout_id<>OLD.layout_id OR NEW.version_no<>OLD.version_no
 THEN RAISE EXCEPTION 'Version identity is immutable'; END IF;
 IF NEW.status IN ('APPROVED','SUPERSEDED') AND OLD.status NOT IN ('SUBMITTED','APPROVED')
 THEN RAISE EXCEPTION 'Submit before approval'; END IF;
 IF NEW.status='APPROVED' AND NOT EXISTS(SELECT 1 FROM finance.layout WHERE id=NEW.layout_id AND status='APPROVED')
 THEN RAISE EXCEPTION 'Layout must be approved'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER version_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.report_version FOR EACH ROW EXECUTE FUNCTION finance.guard_version();
CREATE FUNCTION finance.guard_cell() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE k bigint; st text; typ text; effective_unit text; effective_currency text; BEGIN
 IF TG_OP='UPDATE' AND (NEW.version_id<>OLD.version_id OR NEW.layout_id<>OLD.layout_id)
 THEN RAISE EXCEPTION 'Cannot move cells between versions'; END IF;
 IF TG_OP='DELETE' THEN k:=OLD.version_id; ELSE k:=NEW.version_id; END IF;
 SELECT status INTO st FROM finance.report_version WHERE id=k FOR UPDATE;
 IF st<>'DRAFT' THEN RAISE EXCEPTION 'Only DRAFT cells may be edited'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF;
 SELECT value_type,coalesce(NEW.unit_code,unit_code),coalesce(NEW.currency_code,currency_code) INTO typ,effective_unit,effective_currency FROM finance.layout_column WHERE id=NEW.column_id;
 IF NEW.value_status='PRESENT' AND typ='NUMBER' AND effective_unit='MONEY' AND effective_currency IS NULL
 THEN RAISE EXCEPTION 'Monetary values require an explicit currency'; END IF;
 IF NEW.value_status='PRESENT' AND typ='NUMBER' AND effective_unit<>'MONEY' AND effective_currency IS NOT NULL
 THEN RAISE EXCEPTION 'Non-money numbers must not carry a currency'; END IF;
 IF NEW.value_status='PRESENT' AND NOT (
 (typ='NUMBER' AND NEW.numeric_value IS NOT NULL) OR (typ='TEXT' AND NEW.text_value IS NOT NULL) OR
 (typ='DATE' AND NEW.date_value IS NOT NULL) OR (typ='BOOLEAN' AND NEW.boolean_value IS NOT NULL))
 THEN RAISE EXCEPTION 'Cell type does not match column type'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER cell_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.report_cell FOR EACH ROW EXECUTE FUNCTION finance.guard_cell();
CREATE FUNCTION finance.guard_adjustment() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE k bigint; BEGIN
 IF TG_OP='UPDATE' AND NEW.cell_id<>OLD.cell_id THEN RAISE EXCEPTION 'Cannot move adjustment'; END IF;
 IF TG_OP='DELETE' THEN k:=OLD.cell_id; ELSE k:=NEW.cell_id; END IF;
 PERFORM v.id FROM finance.report_version v JOIN finance.report_cell c ON c.version_id=v.id WHERE c.id=k AND v.status='DRAFT' FOR UPDATE OF v;
 IF NOT FOUND THEN RAISE EXCEPTION 'Adjustments require a DRAFT report version'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER adjustment_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.cell_adjustment FOR EACH ROW EXECUTE FUNCTION finance.guard_adjustment();
CREATE FUNCTION finance.guard_publication() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM finance.report_version WHERE id=NEW.version_id AND series_id=NEW.series_id AND status='APPROVED')
 THEN RAISE EXCEPTION 'Only approved version can be published'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER publication_guard BEFORE INSERT OR UPDATE ON finance.publication FOR EACH ROW EXECUTE FUNCTION finance.guard_publication();
-- Trusted backend must verify approver authority, separation-of-duties policy and scope first.
-- Invoker rights, not SECURITY DEFINER. Approval is explicit; never inferred from file arrival.
CREATE FUNCTION finance.publish_report(p_version bigint,p_actor bigint,p_note text) RETURNS void LANGUAGE plpgsql AS $$
DECLARE v finance.report_version; old_id bigint; BEGIN
 SELECT * INTO STRICT v FROM finance.report_version WHERE id=p_version;
 PERFORM 1 FROM finance.report_series WHERE id=v.series_id FOR UPDATE;
 SELECT * INTO STRICT v FROM finance.report_version WHERE id=p_version FOR UPDATE;
 IF v.status<>'SUBMITTED' THEN RAISE EXCEPTION 'Report must be SUBMITTED'; END IF;
 IF NOT EXISTS(SELECT 1 FROM iam.principal WHERE id=p_actor AND active) THEN RAISE EXCEPTION 'Inactive actor'; END IF;
 IF NOT EXISTS(SELECT 1 FROM finance.report_cell WHERE version_id=p_version) THEN RAISE EXCEPTION 'Empty report'; END IF;
 IF v.ingestion_run_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM source.ingestion_run WHERE id=v.ingestion_run_id AND status='SUCCEEDED')
 THEN RAISE EXCEPTION 'Ingestion run must succeed'; END IF;
 IF v.origin='SYSTEM_CALCULATED' AND NOT EXISTS(SELECT 1 FROM finance.calculation_run WHERE report_version_id=p_version AND status='SUCCEEDED')
 THEN RAISE EXCEPTION 'Successful pinned calculation required'; END IF;
 SELECT version_id INTO old_id FROM finance.publication WHERE series_id=v.series_id;
 UPDATE finance.report_version SET status='APPROVED',approved_by=p_actor,approved_at=clock_timestamp(),approval_note=p_note WHERE id=p_version;
 INSERT INTO finance.publication(series_id,version_id,published_by) VALUES(v.series_id,p_version,p_actor)
 ON CONFLICT(series_id) DO UPDATE SET version_id=EXCLUDED.version_id,published_by=EXCLUDED.published_by,published_at=clock_timestamp();
 IF old_id IS NOT NULL THEN UPDATE finance.report_version SET status='SUPERSEDED' WHERE id=old_id; END IF;
 INSERT INTO audit.event(actor_id,action,object_type,object_id,details)
 VALUES(p_actor,'REPORT_PUBLISHED','REPORT_VERSION',p_version::text,jsonb_build_object('previous_version_id',old_id,'note',p_note));
END $$;

COMMIT;


-- FILE: 006_accounting_inputs.sql
-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

-- Provisional standard accounting contracts; align with actual templates before production loading.
CREATE TABLE finance.account(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, entity_id bigint NOT NULL REFERENCES core.entity(id),
 account_code text NOT NULL, account_name text NOT NULL, account_type text,
 source_company_id bigint, active boolean NOT NULL DEFAULT true,
 FOREIGN KEY(source_company_id,entity_id) REFERENCES source.company(id,entity_id),
 UNIQUE(entity_id,account_code), UNIQUE(id,entity_id));
CREATE TABLE finance.group_account(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL UNIQUE, name text NOT NULL,
 account_type text, parent_id bigint REFERENCES finance.group_account(id), CHECK(parent_id IS NULL OR parent_id<>id));
CREATE TABLE finance.mapping_set(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL, version_no integer NOT NULL CHECK(version_no>0),
 status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','APPROVED','RETIRED')),
 approved_by bigint REFERENCES iam.principal(id), approved_at timestamptz,
 UNIQUE(code,version_no), CHECK(status<>'APPROVED' OR (approved_by IS NOT NULL AND approved_at IS NOT NULL)));
CREATE TABLE finance.account_mapping(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, mapping_set_id bigint NOT NULL REFERENCES finance.mapping_set(id),
 account_id bigint NOT NULL REFERENCES finance.account(id), group_account_id bigint NOT NULL REFERENCES finance.group_account(id),
 sign_multiplier smallint NOT NULL DEFAULT 1 CHECK(sign_multiplier IN (-1,1)),
 effective_from date NOT NULL, effective_to date,
 UNIQUE(mapping_set_id,account_id,effective_from), CHECK(effective_to IS NULL OR effective_to>=effective_from));
COMMENT ON TABLE finance.account_mapping IS 'No account mapping is seeded. Validate overlapping effective ranges and completeness before approval; pin mapping_set in report runs.';
CREATE TABLE finance.trial_balance(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, entity_id bigint NOT NULL REFERENCES core.entity(id),
 period_id bigint NOT NULL REFERENCES core.period(id), currency_code text NOT NULL REFERENCES core.currency(code),
 version_no integer NOT NULL CHECK(version_no>0), basis text NOT NULL
 CHECK(basis IN ('CLOSING','MONTH_MOVEMENT','YTD_MOVEMENT','OPENING')),
 source_kind text NOT NULL CHECK(source_kind IN ('BC','SUBSIDIARY_UPLOAD')),
 run_id bigint NOT NULL REFERENCES source.ingestion_run(id), status text NOT NULL DEFAULT 'DRAFT'
 CHECK(status IN ('DRAFT','VALIDATED','APPROVED','REJECTED')),
 month_end_ready boolean NOT NULL DEFAULT false, approved_by bigint REFERENCES iam.principal(id), approved_at timestamptz,
 UNIQUE(entity_id,period_id,currency_code,basis,source_kind,version_no), UNIQUE(id,entity_id),
 UNIQUE(id,entity_id,period_id,currency_code,basis),
 CHECK(status<>'APPROVED' OR (approved_by IS NOT NULL AND approved_at IS NOT NULL AND month_end_ready)));
CREATE TABLE finance.trial_balance_line(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, trial_balance_id bigint NOT NULL, entity_id bigint NOT NULL,
 account_id bigint NOT NULL, organisation_unit_id bigint, dimension_key text NOT NULL DEFAULT '',
 dimensions jsonb NOT NULL DEFAULT '{}', debit numeric(28,8) NOT NULL CHECK(debit>=0),
 credit numeric(28,8) NOT NULL CHECK(credit>=0), signed_amount numeric(28,8) GENERATED ALWAYS AS (debit-credit) STORED,
 raw_record_id bigint REFERENCES source.raw_record(id), file_record_id bigint REFERENCES source.file_record(id),
 FOREIGN KEY(trial_balance_id,entity_id) REFERENCES finance.trial_balance(id,entity_id),
 FOREIGN KEY(account_id,entity_id) REFERENCES finance.account(id,entity_id),
 FOREIGN KEY(organisation_unit_id,entity_id) REFERENCES core.organisation_unit(id,entity_id),
 UNIQUE NULLS NOT DISTINCT(trial_balance_id,account_id,organisation_unit_id,dimension_key));
COMMENT ON TABLE finance.trial_balance_line IS 'Canonical sign: debit positive, credit negative. Upload adapter must declare incoming convention. Do not sum closing balances across months.';
CREATE TABLE finance.reporting_source_selection(
 entity_id bigint NOT NULL, period_id bigint NOT NULL, currency_code text NOT NULL, basis text NOT NULL,
 trial_balance_id bigint NOT NULL, selected_by bigint NOT NULL REFERENCES iam.principal(id), selected_at timestamptz NOT NULL DEFAULT now(), reason text NOT NULL,
 PRIMARY KEY(entity_id,period_id,currency_code,basis),
 FOREIGN KEY(trial_balance_id,entity_id,period_id,currency_code,basis)
 REFERENCES finance.trial_balance(id,entity_id,period_id,currency_code,basis));
CREATE TABLE finance.source_selection_history(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, occurred_at timestamptz NOT NULL DEFAULT now(),
 entity_id bigint NOT NULL REFERENCES core.entity(id), period_id bigint NOT NULL REFERENCES core.period(id),
 old_trial_balance_id bigint REFERENCES finance.trial_balance(id), new_trial_balance_id bigint NOT NULL REFERENCES finance.trial_balance(id),
 actor_id bigint NOT NULL REFERENCES iam.principal(id), reason text NOT NULL);
CREATE FUNCTION finance.guard_source_selection() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM id FROM finance.trial_balance WHERE id=NEW.trial_balance_id AND status='APPROVED' FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Selected TB must be approved'; END IF;
 INSERT INTO finance.source_selection_history(entity_id,period_id,old_trial_balance_id,new_trial_balance_id,actor_id,reason)
 VALUES(NEW.entity_id,NEW.period_id,CASE WHEN TG_OP='UPDATE' THEN OLD.trial_balance_id ELSE NULL END,NEW.trial_balance_id,NEW.selected_by,NEW.reason);
 RETURN NEW;
END $$;
CREATE TRIGGER selection_guard BEFORE INSERT OR UPDATE ON finance.reporting_source_selection FOR EACH ROW EXECUTE FUNCTION finance.guard_source_selection();
CREATE TRIGGER selection_history_guard BEFORE UPDATE OR DELETE ON finance.source_selection_history FOR EACH ROW EXECUTE FUNCTION audit.deny_mutation();
CREATE TABLE finance.gl_entry(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, company_id bigint NOT NULL, entity_id bigint NOT NULL,
 source_entry_key text NOT NULL, source_version text NOT NULL, account_id bigint NOT NULL,
 posting_date date NOT NULL, document_reference text, currency_code text NOT NULL REFERENCES core.currency(code),
 amount numeric(28,8) NOT NULL, dimensions jsonb NOT NULL DEFAULT '{}',
 raw_record_id bigint NOT NULL REFERENCES source.raw_record(id), source_deleted boolean NOT NULL DEFAULT false,
 FOREIGN KEY(company_id,entity_id) REFERENCES source.company(id,entity_id),
 FOREIGN KEY(account_id,entity_id) REFERENCES finance.account(id,entity_id),
 UNIQUE(company_id,source_entry_key));
CREATE INDEX gl_posting ON finance.gl_entry(entity_id,posting_date,account_id);
COMMENT ON TABLE finance.gl_entry IS 'Current normalised source projection; upsert by company/source key. Raw records preserve successive extraction versions. No implicit report publication.';
CREATE TABLE finance.rule_set(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code text NOT NULL, version_no integer NOT NULL CHECK(version_no>0),
 definition jsonb NOT NULL, status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','APPROVED','RETIRED')),
 approved_by bigint REFERENCES iam.principal(id), approved_at timestamptz,
 UNIQUE(code,version_no), CHECK(status<>'APPROVED' OR (approved_by IS NOT NULL AND approved_at IS NOT NULL)));
CREATE TABLE finance.calculation_run(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, report_version_id bigint NOT NULL UNIQUE REFERENCES finance.report_version(id),
 mapping_set_id bigint NOT NULL REFERENCES finance.mapping_set(id), rule_set_id bigint NOT NULL REFERENCES finance.rule_set(id),
 engine_version text NOT NULL, status text NOT NULL CHECK(status IN ('RUNNING','SUCCEEDED','FAILED')),
 started_at timestamptz NOT NULL DEFAULT now(), finished_at timestamptz);
CREATE TABLE finance.calculation_input(
 calculation_run_id bigint NOT NULL REFERENCES finance.calculation_run(id), trial_balance_id bigint NOT NULL REFERENCES finance.trial_balance(id),
 purpose text NOT NULL CHECK(purpose IN ('PRIMARY','SUPPLEMENT','COMPARISON')),
 PRIMARY KEY(calculation_run_id,trial_balance_id));
CREATE TABLE finance.fx_rate(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, from_currency text NOT NULL REFERENCES core.currency(code),
 to_currency text NOT NULL REFERENCES core.currency(code), rate_date date NOT NULL,
 rate_type text NOT NULL CHECK(rate_type IN ('CLOSING','AVERAGE','HISTORICAL','TRANSACTION')),
 rate numeric(28,12) NOT NULL CHECK(rate>0), source_reference text NOT NULL,
 approved_by bigint NOT NULL REFERENCES iam.principal(id), approved_at timestamptz NOT NULL,
 UNIQUE(from_currency,to_currency,rate_date,rate_type,source_reference), CHECK(from_currency<>to_currency));
CREATE TABLE finance.calculation_fx_input(
 calculation_run_id bigint NOT NULL REFERENCES finance.calculation_run(id), fx_rate_id bigint NOT NULL REFERENCES finance.fx_rate(id),
 PRIMARY KEY(calculation_run_id,fx_rate_id));
CREATE TABLE finance.cell_lineage(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, cell_id bigint NOT NULL REFERENCES finance.report_cell(id),
 trial_balance_line_id bigint REFERENCES finance.trial_balance_line(id), raw_record_id bigint REFERENCES source.raw_record(id),
 file_record_id bigint REFERENCES source.file_record(id), calculation_run_id bigint REFERENCES finance.calculation_run(id),
 transformation_reference text, CHECK(num_nonnulls(trial_balance_line_id,raw_record_id,file_record_id,calculation_run_id)=1));

COMMIT;


-- FILE: 007_banking_operations.sql
-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

CREATE TABLE finance.bank_account(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, entity_id bigint NOT NULL REFERENCES core.entity(id),
 code text NOT NULL UNIQUE, bank_name text NOT NULL, account_display text NOT NULL,
 currency_code text NOT NULL REFERENCES core.currency(code), active boolean NOT NULL DEFAULT true,
 UNIQUE(id,entity_id), UNIQUE(id,currency_code));
COMMENT ON COLUMN finance.bank_account.account_display IS 'Masked display identifier only. Full account numbers require protected storage, not numeric fields.';
CREATE TABLE finance.bank_connection(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, bank_account_id bigint NOT NULL REFERENCES finance.bank_account(id),
 instance_id bigint NOT NULL REFERENCES source.instance(id), provider_account_key text NOT NULL,
 consent_reference text, consent_expires_at timestamptz,
 status text NOT NULL CHECK(status IN ('PENDING','ACTIVE','REAUTHORISATION_REQUIRED','DISABLED')),
 last_attempt_at timestamptz, last_success_at timestamptz, last_error text,
 UNIQUE(instance_id,provider_account_key), UNIQUE(id,bank_account_id));
CREATE TABLE finance.bank_book_mapping(
 bank_account_id bigint NOT NULL, entity_id bigint NOT NULL, company_id bigint NOT NULL,
 external_bank_account_key text NOT NULL, gl_account_id bigint,
 FOREIGN KEY(bank_account_id,entity_id) REFERENCES finance.bank_account(id,entity_id),
 FOREIGN KEY(company_id,entity_id) REFERENCES source.company(id,entity_id),
 FOREIGN KEY(gl_account_id,entity_id) REFERENCES finance.account(id,entity_id),
 PRIMARY KEY(bank_account_id,company_id,external_bank_account_key));
CREATE TABLE finance.bank_balance_snapshot(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, bank_account_id bigint NOT NULL, connection_id bigint NOT NULL,
 currency_code text NOT NULL, balance_type text NOT NULL, amount numeric(28,8) NOT NULL,
 source_as_of timestamptz, retrieved_at timestamptz NOT NULL, refresh_confirmed_at timestamptz,
 raw_amount numeric(30,8) NOT NULL, raw_unit_divisor numeric NOT NULL CHECK(raw_unit_divisor>0),
 provider_snapshot_key text NOT NULL, raw_record_id bigint NOT NULL REFERENCES source.raw_record(id),
 FOREIGN KEY(connection_id,bank_account_id) REFERENCES finance.bank_connection(id,bank_account_id),
 FOREIGN KEY(bank_account_id,currency_code) REFERENCES finance.bank_account(id,currency_code),
 UNIQUE(connection_id,provider_snapshot_key,balance_type),
 CHECK(amount=raw_amount/raw_unit_divisor));
COMMENT ON TABLE finance.bank_balance_snapshot IS 'Only successful observations. Adapter confirms provider units/type; never store refresh failure as zero. Retrieval time alone does not prove provider freshness. No FX aggregation in this table.';
CREATE TABLE finance.bank_book_balance(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, bank_account_id bigint NOT NULL,
 as_of_date date NOT NULL, currency_code text NOT NULL, amount numeric(28,8) NOT NULL,
 run_id bigint NOT NULL REFERENCES source.ingestion_run(id), source_reference text NOT NULL,
 FOREIGN KEY(bank_account_id,currency_code) REFERENCES finance.bank_account(id,currency_code),
 UNIQUE(bank_account_id,as_of_date,run_id));
CREATE TABLE finance.submission_requirement(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, dataset_id bigint NOT NULL REFERENCES core.dataset(id),
 entity_id bigint NOT NULL REFERENCES core.entity(id), period_id bigint NOT NULL REFERENCES core.period(id),
 deadline_at timestamptz NOT NULL, business_timezone text NOT NULL DEFAULT 'Africa/Lagos',
 counting_method text CHECK(counting_method IN ('CALENDAR_DAY','BUSINESS_DAY','ELAPSED_HOURS')),
 UNIQUE(dataset_id,entity_id,period_id));
CREATE TABLE finance.submission_event(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, requirement_id bigint NOT NULL REFERENCES finance.submission_requirement(id),
 submitted_at timestamptz NOT NULL, received_at timestamptz NOT NULL DEFAULT now(),
 source_file_id bigint REFERENCES source.file(id), source_event_reference text NOT NULL UNIQUE,
 event_type text NOT NULL CHECK(event_type IN ('INITIAL','CORRECTION')), actor_id bigint REFERENCES iam.principal(id), evidence_reference text NOT NULL);
COMMENT ON TABLE finance.submission_event IS 'Capture true submission evidence, not database ingestion time. Finance confirms first/latest accepted event, day-counting and scoring before heat-map automation.';
CREATE TABLE finance.incubated_expense_allocation(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, beneficiary_entity_id bigint NOT NULL REFERENCES core.entity(id),
 payer_entity_id bigint NOT NULL REFERENCES core.entity(id), expense_date date NOT NULL,
 category text NOT NULL, amount numeric(28,8) NOT NULL, currency_code text NOT NULL REFERENCES core.currency(code),
 payment_reference text NOT NULL, allocation_reference text NOT NULL UNIQUE,
 evidence_file_id bigint NOT NULL REFERENCES source.file(id), approved_by bigint REFERENCES iam.principal(id), approved_at timestamptz,
 CHECK((approved_by IS NULL)=(approved_at IS NULL)));
COMMENT ON TABLE finance.incubated_expense_allocation IS 'Controlled imports of the existing log; not a new expense request or payment workflow. Beneficiary cannot be inferred from vendor narration alone.';
CREATE INDEX bank_balance_time ON finance.bank_balance_snapshot(bank_account_id,retrieved_at DESC);


-- Supporting facts from supplied report structures; optional for Delivery 1 prepared-output imports.
CREATE TABLE finance.intercompany_position(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, book_entity_id bigint NOT NULL REFERENCES core.entity(id),
 counterparty_entity_id bigint NOT NULL REFERENCES core.entity(id), period_id bigint NOT NULL REFERENCES core.period(id),
 currency_code text NOT NULL REFERENCES core.currency(code), receivable numeric(28,8) NOT NULL CHECK(receivable>=0),
 payable numeric(28,8) NOT NULL CHECK(payable>=0), net_receivable numeric(28,8) GENERATED ALWAYS AS (receivable-payable) STORED,
 run_id bigint NOT NULL REFERENCES source.ingestion_run(id), file_record_id bigint REFERENCES source.file_record(id),
 CHECK(book_entity_id<>counterparty_entity_id), UNIQUE(book_entity_id,counterparty_entity_id,period_id,currency_code,run_id));
COMMENT ON TABLE finance.intercompany_position IS 'Book entity and counterparty are explicit. Do not auto-eliminate or net across currencies; agree matching, differences and consolidation rules with Finance.';
CREATE TABLE finance.debt_facility(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, entity_id bigint NOT NULL REFERENCES core.entity(id),
 facility_code text NOT NULL UNIQUE, lender_name text NOT NULL, currency_code text NOT NULL REFERENCES core.currency(code),
 agreement_file_id bigint REFERENCES source.file(id), UNIQUE(id,currency_code));
CREATE TABLE finance.debt_schedule_line(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, facility_id bigint NOT NULL, currency_code text NOT NULL,
 due_date date NOT NULL, basis text NOT NULL CHECK(basis IN ('ACTUAL','SCHEDULED','FORECAST')),
 opening_principal numeric(28,8), accrued_interest numeric(28,8), principal_payment numeric(28,8),
 total_payment numeric(28,8), closing_balance numeric(28,8), run_id bigint NOT NULL REFERENCES source.ingestion_run(id),
 file_record_id bigint REFERENCES source.file_record(id),
 FOREIGN KEY(facility_id,currency_code) REFERENCES finance.debt_facility(id,currency_code),
 UNIQUE(facility_id,due_date,basis,run_id));
COMMENT ON TABLE finance.debt_schedule_line IS 'Imported schedule observations. No inferred interest, capitalisation, drawdown or repayment formula; supplied figures are reconciled without silently repairing them.';
CREATE TABLE finance.partner_expense(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, payer_entity_id bigint NOT NULL REFERENCES core.entity(id),
 partner_reference text NOT NULL, expense_date date NOT NULL, category text, description text,
 payment_method text, payment_reference text, payment_status text,
 amount numeric(28,8) NOT NULL, currency_code text NOT NULL REFERENCES core.currency(code),
 run_id bigint NOT NULL REFERENCES source.ingestion_run(id), file_record_id bigint NOT NULL REFERENCES source.file_record(id),
 UNIQUE(run_id,file_record_id,currency_code));
COMMENT ON TABLE finance.partner_expense IS 'Restricted supporting facts. NGN and USD are separate observations, not amounts to sum without an approved FX rule. Authorise this dataset separately from general group reports.';
COMMIT;


-- FILE: 008_dictionary_governance.sql
-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

CREATE TABLE core.template_contract(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, dataset_id bigint NOT NULL REFERENCES core.dataset(id),
 version_no integer NOT NULL CHECK(version_no>0), status text NOT NULL DEFAULT 'PENDING'
 CHECK(status IN ('PENDING','DRAFT','APPROVED','RETIRED')), row_grain text, submission_frequency text,
 evidence_file_id bigint REFERENCES source.file(id), business_approved_by bigint REFERENCES iam.principal(id),
 business_approved_at timestamptz, technical_verified_by bigint REFERENCES iam.principal(id), technical_verified_at timestamptz,
 UNIQUE(dataset_id,version_no), CHECK(status<>'APPROVED' OR (business_approved_by IS NOT NULL AND business_approved_at IS NOT NULL)));
CREATE TABLE core.field_definition(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, dataset_id bigint NOT NULL REFERENCES core.dataset(id),
 code text NOT NULL, version_no integer NOT NULL CHECK(version_no>0), business_name text NOT NULL, definition text,
 logical_type text NOT NULL, required boolean NOT NULL DEFAULT false, allowed_values jsonb,
 unit_code text REFERENCES core.unit(code), balance_basis text, aggregation_rule text, sign_convention text,
 sensitivity text NOT NULL DEFAULT 'CONFIDENTIAL' CHECK(sensitivity IN ('PUBLIC','INTERNAL','CONFIDENTIAL','RESTRICTED')),
 physical_schema text, physical_table text, physical_column text,
 business_approved_by bigint REFERENCES iam.principal(id), business_approved_at timestamptz,
 technical_verified_by bigint REFERENCES iam.principal(id), technical_verified_at timestamptz,
 status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','PENDING','APPROVED','RETIRED')),
 UNIQUE(dataset_id,code,version_no));
CREATE TABLE core.source_field_mapping(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, field_id bigint NOT NULL REFERENCES core.field_definition(id),
 company_id bigint REFERENCES source.company(id), entity_id bigint REFERENCES core.entity(id),
 source_reference text NOT NULL, source_field_path text NOT NULL, transformation_reference text,
 purpose text NOT NULL CHECK(purpose IN ('PRIMARY','SUPPLEMENT','REPLACEMENT','COMPARISON')),
 effective_from date NOT NULL, effective_to date, CHECK(effective_to IS NULL OR effective_to>=effective_from));
CREATE TABLE core.quality_rule(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, dataset_id bigint NOT NULL REFERENCES core.dataset(id),
 code text NOT NULL, version_no integer NOT NULL CHECK(version_no>0), description text NOT NULL,
 validation_reference text NOT NULL, tolerance numeric, severity text NOT NULL CHECK(severity IN ('INFO','WARNING','BLOCKER')),
 business_owner text, UNIQUE(dataset_id,code,version_no));
CREATE TABLE core.lineage_edge(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, from_reference text NOT NULL, to_reference text NOT NULL,
 transformation_reference text, effective_from date NOT NULL, effective_to date,
 CHECK(effective_to IS NULL OR effective_to>=effective_from));
CREATE TABLE core.definition_change(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, object_reference text NOT NULL,
 changed_by bigint NOT NULL REFERENCES iam.principal(id), changed_at timestamptz NOT NULL DEFAULT now(), reason text NOT NULL,
 old_version text, new_version text);
CREATE TABLE ai.route_policy(
 sensitivity text PRIMARY KEY CHECK(sensitivity IN ('PUBLIC','INTERNAL','CONFIDENTIAL','RESTRICTED')),
 route text NOT NULL DEFAULT 'BLOCKED' CHECK(route IN ('BLOCKED','PRIVATE_APPROVED','EXTERNAL_APPROVED')),
 approved_by bigint REFERENCES iam.principal(id), approved_at timestamptz,
 CHECK(route='BLOCKED' OR (approved_by IS NOT NULL AND approved_at IS NOT NULL)));
CREATE TABLE ai.question_event(
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, actor_id bigint NOT NULL REFERENCES iam.principal(id),
 occurred_at timestamptz NOT NULL DEFAULT now(), dataset_id bigint REFERENCES core.dataset(id),
 route_decision text NOT NULL DEFAULT 'BLOCKED', retrieval_references jsonb NOT NULL DEFAULT '[]', outcome text NOT NULL);
COMMENT ON SCHEMA ai IS 'Future governance metadata only; no model execution, agent runtime or AI rollout included.';
-- Freeze approved TB data and approved mapping/rule definitions. SQL owner can always bypass controls.
CREATE FUNCTION finance.guard_approved_parent() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF OLD.status='APPROVED' THEN RAISE EXCEPTION 'Approved input/definition is immutable; create a new version'; END IF;
 IF TG_OP='UPDATE' AND NEW.status='APPROVED' THEN
  IF TG_TABLE_NAME='trial_balance' THEN
   IF NOT EXISTS(SELECT 1 FROM source.ingestion_run WHERE id=NEW.run_id AND status='SUCCEEDED')
   THEN RAISE EXCEPTION 'TB source run must succeed'; END IF;
  END IF;
  IF TG_TABLE_NAME='mapping_set' AND EXISTS(SELECT 1 FROM finance.account_mapping a JOIN finance.account_mapping b
   ON a.mapping_set_id=b.mapping_set_id AND a.account_id=b.account_id AND a.id<b.id
   AND daterange(a.effective_from,a.effective_to,'[]') && daterange(b.effective_from,b.effective_to,'[]')
   WHERE a.mapping_set_id=NEW.id) THEN RAISE EXCEPTION 'Overlapping account mappings'; END IF;
 END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER tb_guard BEFORE UPDATE OR DELETE ON finance.trial_balance FOR EACH ROW EXECUTE FUNCTION finance.guard_approved_parent();
CREATE TRIGGER mapping_set_guard BEFORE UPDATE OR DELETE ON finance.mapping_set FOR EACH ROW EXECUTE FUNCTION finance.guard_approved_parent();
CREATE TRIGGER rule_set_guard BEFORE UPDATE OR DELETE ON finance.rule_set FOR EACH ROW EXECUTE FUNCTION finance.guard_approved_parent();
CREATE FUNCTION finance.guard_tb_line() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE k bigint; st text; BEGIN
 IF TG_OP='UPDATE' AND NEW.trial_balance_id<>OLD.trial_balance_id THEN RAISE EXCEPTION 'Cannot move TB line'; END IF;
 IF TG_OP='DELETE' THEN k:=OLD.trial_balance_id; ELSE k:=NEW.trial_balance_id; END IF;
 SELECT status INTO st FROM finance.trial_balance WHERE id=k FOR UPDATE;
 IF st<>'DRAFT' THEN RAISE EXCEPTION 'TB lines require DRAFT parent'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER tb_line_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.trial_balance_line FOR EACH ROW EXECUTE FUNCTION finance.guard_tb_line();
CREATE FUNCTION finance.guard_mapping_member() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE k bigint; st text; BEGIN
 IF TG_OP='UPDATE' AND NEW.mapping_set_id<>OLD.mapping_set_id THEN RAISE EXCEPTION 'Cannot move account mapping'; END IF;
 IF TG_OP='DELETE' THEN k:=OLD.mapping_set_id; ELSE k:=NEW.mapping_set_id; END IF;
 SELECT status INTO st FROM finance.mapping_set WHERE id=k FOR UPDATE;
 IF st<>'DRAFT' THEN RAISE EXCEPTION 'Mappings require DRAFT parent'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER mapping_member_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.account_mapping FOR EACH ROW EXECUTE FUNCTION finance.guard_mapping_member();


CREATE TRIGGER raw_record_immutable BEFORE UPDATE OR DELETE ON source.raw_record FOR EACH ROW EXECUTE FUNCTION audit.deny_mutation();
CREATE TRIGGER file_evidence_immutable BEFORE UPDATE OR DELETE ON source.file FOR EACH ROW EXECUTE FUNCTION audit.deny_mutation();
CREATE TRIGGER file_record_immutable BEFORE UPDATE OR DELETE ON source.file_record FOR EACH ROW EXECUTE FUNCTION audit.deny_mutation();
CREATE TRIGGER bank_snapshot_immutable BEFORE UPDATE OR DELETE ON finance.bank_balance_snapshot FOR EACH ROW EXECUTE FUNCTION audit.deny_mutation();
CREATE TRIGGER fx_rate_immutable BEFORE UPDATE OR DELETE ON finance.fx_rate FOR EACH ROW EXECUTE FUNCTION audit.deny_mutation();
CREATE FUNCTION finance.guard_series() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF EXISTS(SELECT 1 FROM finance.report_version WHERE series_id=OLD.id)
 THEN RAISE EXCEPTION 'Report series identity is immutable once versions exist'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER series_guard BEFORE UPDATE OR DELETE ON finance.report_series FOR EACH ROW EXECUTE FUNCTION finance.guard_series();
CREATE FUNCTION finance.guard_calculation_run() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE v finance.report_version; BEGIN
 IF TG_OP<>'INSERT' AND OLD.status='SUCCEEDED' THEN RAISE EXCEPTION 'Successful calculation is immutable'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF;
 SELECT * INTO STRICT v FROM finance.report_version WHERE id=NEW.report_version_id FOR UPDATE;
 IF v.status<>'DRAFT' OR v.origin<>'SYSTEM_CALCULATED' THEN RAISE EXCEPTION 'Calculation requires draft system-calculated report'; END IF;
 IF NOT EXISTS(SELECT 1 FROM finance.mapping_set WHERE id=NEW.mapping_set_id AND status='APPROVED')
 OR NOT EXISTS(SELECT 1 FROM finance.rule_set WHERE id=NEW.rule_set_id AND status='APPROVED')
 THEN RAISE EXCEPTION 'Calculation definitions must be approved'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER calculation_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.calculation_run FOR EACH ROW EXECUTE FUNCTION finance.guard_calculation_run();
CREATE FUNCTION finance.guard_calculation_input() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE k bigint; st text; BEGIN
 IF TG_OP='UPDATE' AND NEW.calculation_run_id<>OLD.calculation_run_id THEN RAISE EXCEPTION 'Cannot move calculation input'; END IF;
 IF TG_OP='DELETE' THEN k:=OLD.calculation_run_id; ELSE k:=NEW.calculation_run_id; END IF;
 SELECT status INTO st FROM finance.calculation_run WHERE id=k FOR UPDATE;
 IF st<>'RUNNING' THEN RAISE EXCEPTION 'Inputs require RUNNING calculation'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF;
 IF TG_TABLE_NAME='calculation_input' AND NOT EXISTS(SELECT 1 FROM finance.trial_balance WHERE id=NEW.trial_balance_id AND status='APPROVED')
 THEN RAISE EXCEPTION 'Calculation input TB must be approved'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER calculation_input_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.calculation_input FOR EACH ROW EXECUTE FUNCTION finance.guard_calculation_input();
-- Separate FX trigger avoids referencing a field not present on the FX input record.
CREATE FUNCTION finance.guard_calculation_fx() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE k bigint; st text; BEGIN
 IF TG_OP='UPDATE' AND NEW.calculation_run_id<>OLD.calculation_run_id THEN RAISE EXCEPTION 'Cannot move FX input'; END IF;
 IF TG_OP='DELETE' THEN k:=OLD.calculation_run_id; ELSE k:=NEW.calculation_run_id; END IF;
 SELECT status INTO st FROM finance.calculation_run WHERE id=k FOR UPDATE;
 IF st<>'RUNNING' THEN RAISE EXCEPTION 'FX inputs require RUNNING calculation'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER calculation_fx_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.calculation_fx_input FOR EACH ROW EXECUTE FUNCTION finance.guard_calculation_fx();
CREATE TRIGGER cell_lineage_guard BEFORE INSERT OR UPDATE OR DELETE ON finance.cell_lineage FOR EACH ROW EXECUTE FUNCTION finance.guard_adjustment();
-- Successful runs/validation evidence cannot subsequently be rewritten by normal DML.
CREATE FUNCTION source.guard_successful_run() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF OLD.status='SUCCEEDED' THEN RAISE EXCEPTION 'Completed ingestion run is immutable'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER run_guard BEFORE UPDATE OR DELETE ON source.ingestion_run FOR EACH ROW EXECUTE FUNCTION source.guard_successful_run();
COMMIT;


-- FILE: 009_serving_views.sql
-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

-- These are trusted BACKEND views, not automatic per-user/entity security boundaries.
CREATE VIEW finance.v_published_cells AS
SELECT r.id AS report_id,r.code AS report_code,r.name AS report_name,
 s.id AS series_id,s.period_id AS publication_period_id,s.scope_entity_id,s.variant_code,
 v.id AS version_id,v.version_no,v.origin,v.approved_at,p.published_at,v.layout_id,
 rw.id AS row_id,rw.code AS row_code,rw.label AS row_label,rw.row_type,rw.display_order AS row_order,
 col.id AS column_id,col.code AS column_code,col.label AS column_label,col.display_order AS column_order,
 col.period_id AS observation_period_id,col.scenario_code,col.value_type,
 coalesce(c.unit_code,col.unit_code) AS unit_code,coalesce(c.currency_code,col.currency_code) AS currency_code,
 col.display_scale,col.decimals,c.id AS cell_id,c.value_status,c.numeric_value,
 c.numeric_value/col.display_scale AS display_numeric_value,c.text_value,c.date_value,c.boolean_value,
 coalesce(c.entity_id,col.entity_id,rw.entity_id) AS observation_entity_id,c.organisation_unit_id,
 v.source_file_id,c.source_file_record_id,c.source_raw_record_id
FROM finance.publication p
JOIN finance.report_version v ON v.id=p.version_id AND v.status='APPROVED'
JOIN finance.report_series s ON s.id=v.series_id
JOIN finance.report r ON r.id=s.report_id
JOIN finance.layout_row rw ON rw.layout_id=v.layout_id
JOIN finance.report_cell c ON c.version_id=v.id AND c.row_id=rw.id
JOIN finance.layout_column col ON col.id=c.column_id;
CREATE VIEW finance.v_approved_history_cells AS
SELECT v.series_id,v.version_no,v.status,v.origin,v.approved_at,c.*
FROM finance.report_version v JOIN finance.report_cell c ON c.version_id=v.id
WHERE v.status IN ('APPROVED','SUPERSEDED');
CREATE VIEW finance.v_selected_tb AS
SELECT s.entity_id,s.period_id,s.currency_code,s.basis,s.trial_balance_id,l.id AS trial_balance_line_id,
 l.account_id,l.organisation_unit_id,l.dimension_key,l.debit,l.credit,l.signed_amount
FROM finance.reporting_source_selection s JOIN finance.trial_balance t ON t.id=s.trial_balance_id AND t.status='APPROVED'
JOIN finance.trial_balance_line l ON l.trial_balance_id=t.id;
CREATE VIEW finance.v_latest_bank_balance AS
SELECT DISTINCT ON (b.bank_account_id,b.balance_type)
 a.entity_id,a.code AS account_code,a.bank_name,a.account_display,b.*,
 cn.status AS connection_status,cn.last_attempt_at,cn.last_success_at,cn.last_error
FROM finance.bank_balance_snapshot b JOIN finance.bank_account a ON a.id=b.bank_account_id
JOIN finance.bank_connection cn ON cn.id=b.connection_id
ORDER BY b.bank_account_id,b.balance_type,b.retrieved_at DESC,b.id DESC;
COMMENT ON VIEW finance.v_latest_bank_balance IS 'One last successful observation per account/type. Backend must display unknown/stale source time, connection failures and missing account coverage; no universal freshness threshold assumed.';
CREATE VIEW core.v_physical_dictionary AS
SELECT table_schema,table_name,column_name,data_type,is_nullable,column_default
FROM information_schema.columns WHERE table_schema IN ('core','iam','source','finance','audit','ai','hr','ops','risk','legal','product');
CREATE VIEW source.v_run_status AS
SELECT r.id,r.status,r.stream_id,r.file_id,r.started_at,r.finished_at,r.rows_read,r.rows_accepted,r.rows_rejected,r.error_summary,
 s.endpoint_code,c.entity_id,i.code AS instance_code
FROM source.ingestion_run r LEFT JOIN source.sync_stream s ON s.id=r.stream_id
LEFT JOIN source.company c ON c.id=s.company_id LEFT JOIN source.instance i ON i.id=c.instance_id;

COMMIT;


-- FILE: 010_reference_seed.sql
-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

INSERT INTO core.module(code,name) VALUES ('FINANCE','Finance'),('HR','People'),('OPERATIONS','Operations'),('RISK','Risk'),('LEGAL','Legal'),('PRODUCT','Product');
INSERT INTO core.currency(code,name) VALUES ('NGN','Nigerian naira'),('USD','US dollar'),('GBP','Pound sterling'),('EUR','Euro'),('KES','Kenyan shilling');
INSERT INTO core.unit(code,name) VALUES ('MONEY','Currency amount'),('PERCENT','Percentage points'),('DAYS','Days'),('COUNT','Count'),('RATIO','Ratio'),('TEXT','Text'),('DATE','Date'),('BOOLEAN','Boolean');
INSERT INTO core.scenario(code,name) VALUES ('ACTUAL','Actual'),('BUDGET','Budget'),('FORECAST','Forecast');
-- No guessed subsidiary functional currencies, bank accounts, permissions or IAM provider seeded.
INSERT INTO core.entity(code,name,entity_type) VALUES ('VGG_GROUP','VGG Group','GROUP');
INSERT INTO source.system(code,name,kind) VALUES ('BUSINESS_CENTRAL','Business Central','ERP'),('MONO','Mono','BANK_API'),('FINANCE_WORKBOOK','Finance reporting workbook','WORKBOOK'),('SUPPORTING_DOCUMENTS','Supporting evidence','DOCUMENT_STORE');
INSERT INTO core.dataset(code,name,module_code,definition_status) VALUES
 ('FINANCE_GROUP_REPORTS','Prepared Finance group report outputs','FINANCE','DRAFT'),
 ('CHART_OF_ACCOUNTS','Chart of accounts input template','FINANCE','PENDING'),
 ('TRIAL_BALANCE','Trial balance input template','FINANCE','PENDING'),
 ('TEMPLATE_PENDING_03','Input template 3: awaiting definition','FINANCE','PENDING'),
 ('TEMPLATE_PENDING_04','Input template 4: awaiting definition','FINANCE','PENDING'),
 ('TEMPLATE_PENDING_05','Input template 5: awaiting definition','FINANCE','PENDING'),
 ('TEMPLATE_PENDING_06','Input template 6: awaiting definition','FINANCE','PENDING'),
 ('TEMPLATE_PENDING_07','Input template 7: awaiting definition','FINANCE','PENDING'),
 ('TEMPLATE_PENDING_08','Input template 8: awaiting definition','FINANCE','PENDING'),
 ('BANK_BALANCES','Bank balance observations','FINANCE','DRAFT');
INSERT INTO core.template_contract(dataset_id,version_no)
SELECT id,1 FROM core.dataset WHERE code IN ('CHART_OF_ACCOUNTS','TRIAL_BALANCE') OR code LIKE 'TEMPLATE_PENDING_%';
INSERT INTO ai.route_policy(sensitivity) VALUES ('PUBLIC'),('INTERNAL'),('CONFIDENTIAL'),('RESTRICTED');
INSERT INTO core.schema_version(version) VALUES ('0.3.0');

COMMIT;


-- FILE: 011_report_catalogue_candidates.sql
-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

-- Confirm 13-report scope vs 14 tabs; two weekly cash sheets may be parts of one report.
-- This seeds catalogue candidates only, NOT report definitions, historical values or financial rules.
INSERT INTO finance.report(code,name,source_sheet,dataset_id,notes)
SELECT x.code,x.name,x.name,d.id,'Workbook candidate: Finance to confirm scope, owner, cadence, layout and history.'
FROM (VALUES ('COMPLIANCE','Compliance Report'),
('WEEKLY_CASH_1','Weekly Cash Position 1'),
('WEEKLY_CASH_2','Weekly Cash Position 2'),
('MANCO_FINANCIALS','Manco Financials'),
('VGG_SOFP','Vgg SOFP'),
('INCUBATED_INVESTMENTS','Investment in incubated Com'),
('INTERCOMPANY_OWINGS','Intercompany owings'),
('GROUP_MANAGEMENT','Group Management Acc'),
('SERVICE_COMPANIES','Service Company Report'),
('ACTUAL_BUDGET','Actual Vs Budget Report'),
('GROUP_MONTH_ON_MONTH','Group Month on Month'),
('SUBMISSION_HEAT_MAP','Monthly Heat Map Report'),
('PARTNERS_EXPENSES','Partners Expense Report'),
('DEBT_OBLIGATIONS','Debt Obligation Report')) AS x(code,name)
CROSS JOIN core.dataset d WHERE d.code='FINANCE_GROUP_REPORTS';

COMMIT;


-- FILE: 012_security_baseline.sql
-- VGG OS v0.3 | Fresh install | PostgreSQL 15+
BEGIN;

-- Installer owns objects. Provision separate, private backend logins via IT; never connect browsers directly.
REVOKE ALL ON SCHEMA core,iam,source,finance,audit,ai,hr,ops,risk,legal,product FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA core,iam,source,finance,audit,ai FROM PUBLIC;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA core,iam,source,finance,audit,ai FROM PUBLIC;
REVOKE EXECUTE ON ALL FUNCTIONS IN SCHEMA core,iam,source,finance,audit,ai FROM PUBLIC;
-- Default privileges apply to objects subsequently created BY THIS installer role.
ALTER DEFAULT PRIVILEGES IN SCHEMA core,iam,source,finance,audit,ai REVOKE ALL ON TABLES FROM PUBLIC;
ALTER DEFAULT PRIVILEGES IN SCHEMA core,iam,source,finance,audit,ai REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;
-- Grant no access until Engineering confirms identity, backend roles and entity/report scope rules.
-- Table owner/superuser is not a runtime account. This is a server-authorised model, not RLS.

COMMIT;
